# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk_p_i rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk_p_i/func_mode
create_ccopt_skew_group -name clk_p_i/func_mode -from_clocks {clk_p_i} -from_constraint_modes {func_mode} -from_delay_corners {DC_max DC_min} -target_insertion_delay 0.500 -auto_sinks -sources {clk_p_i}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group: clk_p_i/scan_mode
create_ccopt_skew_group -name clk_p_i/scan_mode -from_clocks {clk_p_i} -from_constraint_modes {scan_mode} -from_delay_corners {DC_max DC_min} -target_insertion_delay 0.500 -auto_sinks -sources {clk_p_i}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 1.087 -target_skew 0.020 -sinks {{alu_in/ALU_d2_r_reg[14]/CK} {alu_in/ALU_d2_r_reg[15]/CK} {alu_in/ALU_d2_r_reg[13]/CK} {alu_in/ALU_d2_r_reg[12]/CK} {alu_in/ALU_d2_r_reg[11]/CK} {alu_in/ALU_d2_r_reg[10]/CK} {alu_in/ALU_d2_r_reg[7]/CK} {alu_in/ALU_d2_r_reg[9]/CK} {alu_in/ALU_d2_r_reg[3]/CK} {alu_in/ALU_d2_r_reg[6]/CK} {alu_in/ALU_d2_r_reg[0]/CK} {alu_in/ALU_d2_r_reg[8]/CK} {alu_in/ALU_d2_r_reg[5]/CK} {alu_in/ALU_d2_r_reg[2]/CK} {alu_in/ALU_d2_r_reg[4]/CK} {alu_in/ALU_d2_r_reg[1]/CK} {alu_in/reg_data_a_reg[0]/CK} {alu_in/reg_data_a_reg[1]/CK} {alu_in/reg_data_b_reg[2]/CK} {alu_in/reg_data_b_reg[0]/CK} {alu_in/reg_data_a_reg[2]/CK} {alu_in/reg_data_a_reg[3]/CK} {alu_in/reg_data_a_reg[4]/CK} {alu_in/reg_data_a_reg[5]/CK} {alu_in/reg_data_a_reg[6]/CK} {alu_in/reg_data_a_reg[7]/CK} {alu_in/reg_data_b_reg[1]/CK} {alu_in/reg_data_b_reg[3]/CK} {alu_in/reg_data_b_reg[4]/CK} {alu_in/reg_data_b_reg[5]/CK} {alu_in/reg_data_b_reg[6]/CK} {alu_in/reg_data_b_reg[7]/CK} {alu_in/reg_inst_reg[1]/CK} {alu_in/reg_inst_reg[2]/CK} {alu_in/reg_inst_reg[0]/CK}} -rank 0 -sources {{clk_p_i rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment_wns
switch_ccopt_skew_group_mode -create fragment_wns
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[11]/CK} {0 -1.49375e-12}
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[10]/CK} {0 -1.49375e-12}
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[9]/CK} {0 -1.49375e-12}
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[6]/CK} {0 1.48648e-12}
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[8]/CK} {0 -1.49375e-12}
set_ccopt_property insertion_delay -delay_corner DC_max -late -rise -pin {alu_in/ALU_d2_r_reg[5]/CK} {0 1.48648e-12}
# Skew Group: clk_p_i/func_mode
create_ccopt_skew_group -name clk_p_i/func_mode -target_insertion_delay 0.500 -auto_sinks -sources {clk_p_i}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{clk_p_i rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default
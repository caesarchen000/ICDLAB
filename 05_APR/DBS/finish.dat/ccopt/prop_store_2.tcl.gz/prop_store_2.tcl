# ccopt saved state prop_store_2.tcl.gz

## RestorePhase2: Post-clock-tree extraction.
## Tcl commands to replicate state of the add_driver_cell property.
# add_driver_cell has default value for all objects.
## Tcl commands to replicate state of the add_exclusion_drivers property.
# add_exclusion_drivers has default value.
## Tcl commands to replicate state of the add_new_ports_to_avoid_buffering_nets_with_assigns property.
# add_new_ports_to_avoid_buffering_nets_with_assigns has default value.
## Tcl commands to replicate state of the additional_buffer_depth property.
# additional_buffer_depth has default value for all objects.
## Tcl commands to replicate state of the additional_buffer_depth_skew_group_fraction property.
# additional_buffer_depth_skew_group_fraction has default value.
## Tcl commands to replicate state of the adjacent_rows_legal property.
# adjacent_rows_legal has default value.
## Tcl commands to replicate state of the allow_cg_moves_during_implementation property.
# allow_cg_moves_during_implementation has default value.
## Tcl commands to replicate state of the allow_cloning_in_slew_fixing property.
# allow_cloning_in_slew_fixing has default value.
## Tcl commands to replicate state of the allow_clustering_with_weak_drivers property.
# allow_clustering_with_weak_drivers has default value.
## Tcl commands to replicate state of the allow_commute_inversion_to_above_node property.
# allow_commute_inversion_to_above_node has default value.
## Tcl commands to replicate state of the allow_looser_generated_clock_tree_max_trans_targets property.
# allow_looser_generated_clock_tree_max_trans_targets has default value.
## Tcl commands to replicate state of the allow_nano_route_second_pass_for_drc property.
# allow_nano_route_second_pass_for_drc has default value.
## Tcl commands to replicate state of the allow_no_row_cells property.
# allow_no_row_cells has default value.
## Tcl commands to replicate state of the allow_non_fterm_identical_swaps property.
set_ccopt_property allow_non_fterm_identical_swaps 1
## Tcl commands to replicate state of the allow_preroute_spef_annotation property.
# allow_preroute_spef_annotation has default value.
## Tcl commands to replicate state of the allow_resize_of_dont_touch_cells property.
# allow_resize_of_dont_touch_cells has default value.
## Tcl commands to replicate state of the allow_to_write_fragment_clock_dag_timing_stats_in_log property.
# allow_to_write_fragment_clock_dag_timing_stats_in_log has default value.
## Tcl commands to replicate state of the allow_use_of_nrtd_interface_in_set_net_attributes property.
# allow_use_of_nrtd_interface_in_set_net_attributes has default value.
## Tcl commands to replicate state of the alternative_route_types property.
# alternative_route_types has default value for all objects.
## Tcl commands to replicate state of the always_calculate_effective_direction property.
# always_calculate_effective_direction has default value.
## Tcl commands to replicate state of the always_try_power_domain_crossings property.
# always_try_power_domain_crossings has default value.
## Tcl commands to replicate state of the aocv_estimate_default_stage_count property.
# aocv_estimate_default_stage_count has default value.
## Tcl commands to replicate state of the apply_clock_net_ndrs_before_final_refine_place property.
# apply_clock_net_ndrs_before_final_refine_place has default value.
## Tcl commands to replicate state of the apply_move_limit_after_merging property.
# apply_move_limit_after_merging has default value.
## Tcl commands to replicate state of the apply_source_latency_using_summary property.
# apply_source_latency_using_summary has default value.
## Tcl commands to replicate state of the approximate_balance_attempt_to_buffer_bufferable_subsets property.
# approximate_balance_attempt_to_buffer_bufferable_subsets has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_below_can_change_family property.
# approximate_balance_buffer_below_can_change_family has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_chains_intelligently property.
# approximate_balance_buffer_chains_intelligently has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target property.
# approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_spreading_max_drivers_to_add property.
# approximate_balance_buffer_spreading_max_drivers_to_add has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_spreading_threshold property.
# approximate_balance_buffer_spreading_threshold has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_subsets property.
# approximate_balance_buffer_subsets has default value.
## Tcl commands to replicate state of the approximate_balance_do_buffer_spreading property.
# approximate_balance_do_buffer_spreading has default value.
## Tcl commands to replicate state of the artificially_remove_long_paths_considers_id_targets property.
# artificially_remove_long_paths_considers_id_targets has default value.
## Tcl commands to replicate state of the artificially_remove_long_paths_skew_target_window_multiple property.
# artificially_remove_long_paths_skew_target_window_multiple has default value.
## Tcl commands to replicate state of the assigned_clock_trees property.
# assigned_clock_trees has default value for all objects.
## Tcl commands to replicate state of the auto_design_state_for_ilms property.
# auto_design_state_for_ilms has default value.
## Tcl commands to replicate state of the auto_detect_and_tie_lockup_latches property.
# auto_detect_and_tie_lockup_latches has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_factor property.
# auto_limit_insertion_delay_factor has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_factor_skew_group property.
# auto_limit_insertion_delay_factor_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_decrement property.
# auto_limit_insertion_delay_max_decrement has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_decrement_skew_group property.
# auto_limit_insertion_delay_max_decrement_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_increment property.
# auto_limit_insertion_delay_max_increment has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_increment_skew_group property.
# auto_limit_insertion_delay_max_increment_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_min_insertion_delay_factor property.
# auto_limit_min_insertion_delay_factor has default value.
## Tcl commands to replicate state of the auto_limit_min_insertion_delay_factor_skew_group property.
# auto_limit_min_insertion_delay_factor_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_use_clustering_delays property.
# auto_limit_use_clustering_delays has default value.
## Tcl commands to replicate state of the auto_select_vias property.
# auto_select_vias has default value.
## Tcl commands to replicate state of the auto_wire_skew_proportion property.
# auto_wire_skew_proportion has default value.
## Tcl commands to replicate state of the avoid_escaped_naming property.
# avoid_escaped_naming has default value.
## Tcl commands to replicate state of the avoid_placing_non_spine_cells_on_hard_spines property.
# avoid_placing_non_spine_cells_on_hard_spines has default value.
## Tcl commands to replicate state of the avoid_verilog_escape_when_cloning_bus_ports property.
# avoid_verilog_escape_when_cloning_bus_ports has default value.
## Tcl commands to replicate state of the balance_edge property.
# balance_edge has default value for all objects.
## Tcl commands to replicate state of the bash_timing_graph_after_cluster property.
# bash_timing_graph_after_cluster has default value.
## Tcl commands to replicate state of the bash_timing_graph_before_cluster property.
# bash_timing_graph_before_cluster has default value.
## Tcl commands to replicate state of the boolexp_enable_extra_checks property.
# boolexp_enable_extra_checks has default value.
## Tcl commands to replicate state of the bottom_up_balancer_buffer_dont_touch_node_outputs property.
# bottom_up_balancer_buffer_dont_touch_node_outputs has default value.
## Tcl commands to replicate state of the bottom_up_balancer_start_with_current_max_latencies property.
# bottom_up_balancer_start_with_current_max_latencies has default value.
## Tcl commands to replicate state of the bound_transition_time_to_greater_than_zero property.
# bound_transition_time_to_greater_than_zero has default value.
## Tcl commands to replicate state of the breakpoint_tcl_function property.
# breakpoint_tcl_function has default value.
## Tcl commands to replicate state of the buffer_cells property.
# buffer_cells has default value for all objects.
## Tcl commands to replicate state of the buffer_fanout_in_reducing_insertion_delay_2 property.
# buffer_fanout_in_reducing_insertion_delay_2 has default value.
## Tcl commands to replicate state of the bufferability_use_cache property.
# bufferability_use_cache has default value.
## Tcl commands to replicate state of the call_cong_repair_after_buffering_in_implementation property.
# call_cong_repair_after_buffering_in_implementation has default value.
## Tcl commands to replicate state of the call_cong_repair_after_clustering_and_maybe_cluster_again property.
# call_cong_repair_after_clustering_and_maybe_cluster_again has default value.
## Tcl commands to replicate state of the call_cong_repair_after_initial_clustering property.
# call_cong_repair_after_initial_clustering has default value.
## Tcl commands to replicate state of the call_cong_repair_before_implementation property.
# call_cong_repair_before_implementation has default value.
## Tcl commands to replicate state of the call_cong_repair_during_final_implementation property.
# call_cong_repair_during_final_implementation has default value.
## Tcl commands to replicate state of the call_cong_repair_during_final_implementation_threshold property.
# call_cong_repair_during_final_implementation_threshold has default value.
## Tcl commands to replicate state of the call_cong_repair_during_final_implementation_use_hotspots property.
# call_cong_repair_during_final_implementation_use_hotspots has default value.
## Tcl commands to replicate state of the call_cong_repair_using_flow_tcl property.
# call_cong_repair_using_flow_tcl has default value.
## Tcl commands to replicate state of the call_nanoroute_after_early_global property.
# call_nanoroute_after_early_global has default value.
## Tcl commands to replicate state of the can_add_new_port_checks_if_all_ports_constrained property.
# can_add_new_port_checks_if_all_ports_constrained has default value.
## Tcl commands to replicate state of the can_drive_computation_method property.
# can_drive_computation_method has default value.
## Tcl commands to replicate state of the cannot_clone_reason property.
# cannot_clone_reason has default value for all objects.
## Tcl commands to replicate state of the cannot_fix_pre_route property.
# cannot_fix_pre_route has default value for all objects.
## Tcl commands to replicate state of the cannot_merge_reason property.
set_ccopt_property cannot_merge_reason -inst ipad_clk_p_i {GloballyUnique ClockLogicMergingDisabledOnTree IsDontTouch {correspondingCell: dont_touch.clock_wire} {correspondingCell: dont_touch.placer.lock}}
## Tcl commands to replicate state of the capacitance_margin_absolute property.
# capacitance_margin_absolute has default value.
## Tcl commands to replicate state of the capacitance_margin_percentage property.
# capacitance_margin_percentage has default value.
## Tcl commands to replicate state of the capacitance_override property.
# capacitance_override has default value for all objects.
## Tcl commands to replicate state of the case_analysis property.
set_ccopt_property case_analysis -pin ipad_clk_p_i/PD false
set_ccopt_property case_analysis -pin ipad_clk_p_i/PU false
set_ccopt_property case_analysis -pin ipad_clk_p_i/SMT false
## Tcl commands to replicate state of the caseh_find_better_location_for_node_above_isolated_sink property.
# caseh_find_better_location_for_node_above_isolated_sink has default value.
## Tcl commands to replicate state of the ccopt_adjust_latches_for_hold property.
# ccopt_adjust_latches_for_hold has default value.
## Tcl commands to replicate state of the ccopt_check_db_continue_after_error property.
# ccopt_check_db_continue_after_error has default value.
## Tcl commands to replicate state of the ccopt_check_db_every_tcl_command property.
# ccopt_check_db_every_tcl_command has default value.
## Tcl commands to replicate state of the ccopt_check_db_release_error_object property.
# ccopt_check_db_release_error_object has default value.
## Tcl commands to replicate state of the ccopt_clear_famous_modes_on_exit property.
# ccopt_clear_famous_modes_on_exit has default value.
## Tcl commands to replicate state of the ccopt_clear_hs_data_after_command property.
# ccopt_clear_hs_data_after_command has default value.
## Tcl commands to replicate state of the ccopt_clear_implementation_mode_on_exit property.
# ccopt_clear_implementation_mode_on_exit has default value.
## Tcl commands to replicate state of the ccopt_debug_line_after_initial_clustering property.
# ccopt_debug_line_after_initial_clustering has default value.
## Tcl commands to replicate state of the ccopt_debug_line_before_final_routing property.
# ccopt_debug_line_before_final_routing has default value.
## Tcl commands to replicate state of the ccopt_debug_line_before_post_conditioning property.
# ccopt_debug_line_before_post_conditioning has default value.
## Tcl commands to replicate state of the ccopt_design_default_full_flow_automation property.
# ccopt_design_default_full_flow_automation has default value.
## Tcl commands to replicate state of the ccopt_design_enable_default_tuning property.
# ccopt_design_enable_default_tuning has default value.
## Tcl commands to replicate state of the ccopt_design_localize_cppr_settings property.
# ccopt_design_localize_cppr_settings has default value.
## Tcl commands to replicate state of the ccopt_design_post_db property.
# ccopt_design_post_db has default value.
## Tcl commands to replicate state of the ccopt_design_pre_db property.
# ccopt_design_pre_db has default value.
## Tcl commands to replicate state of the ccopt_design_use_incremental_cppr property.
# ccopt_design_use_incremental_cppr has default value.
## Tcl commands to replicate state of the ccopt_effort_internal_copy property.
set_ccopt_property ccopt_effort_internal_copy low
## Tcl commands to replicate state of the ccopt_enable_detailed_balancer property.
# ccopt_enable_detailed_balancer has default value.
## Tcl commands to replicate state of the ccopt_enable_route_buffering_skew_fixer property.
# ccopt_enable_route_buffering_skew_fixer has default value.
## Tcl commands to replicate state of the ccopt_engine_before_implement_update_timing property.
# ccopt_engine_before_implement_update_timing has default value.
## Tcl commands to replicate state of the ccopt_engine_do_trial_route property.
# ccopt_engine_do_trial_route has default value.
## Tcl commands to replicate state of the ccopt_engine_do_trial_route_before_recluster property.
# ccopt_engine_do_trial_route_before_recluster has default value.
## Tcl commands to replicate state of the ccopt_engine_pin_state property.
# ccopt_engine_pin_state has default value for all objects.
## Tcl commands to replicate state of the ccopt_engine_state property.
# ccopt_engine_state has default value.
## Tcl commands to replicate state of the ccopt_engine_state_reset_on_destroy property.
# ccopt_engine_state_reset_on_destroy has default value.
## Tcl commands to replicate state of the ccopt_implementation_recalculate_windows property.
# ccopt_implementation_recalculate_windows has default value.
## Tcl commands to replicate state of the ccopt_merge_clock_gates property.
# ccopt_merge_clock_gates has default value for all objects.
## Tcl commands to replicate state of the ccopt_merge_clock_logic property.
# ccopt_merge_clock_logic has default value for all objects.
## Tcl commands to replicate state of the ccopt_operations_after_tns_opt property.
# ccopt_operations_after_tns_opt has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_high property.
# ccopt_operations_critical_high has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_low property.
# ccopt_operations_critical_low has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_medium property.
# ccopt_operations_critical_medium has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_high property.
# ccopt_operations_extended_high has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_low property.
# ccopt_operations_extended_low has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_medium property.
# ccopt_operations_extended_medium has default value.
## Tcl commands to replicate state of the ccopt_post_route_leave_clock_tree_cells_placed property.
# ccopt_post_route_leave_clock_tree_cells_placed has default value.
## Tcl commands to replicate state of the ccopt_property_return_display_limit property.
# ccopt_property_return_display_limit has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_hyperspace_cluster property.
# ccopt_refresh_schedule_before_hyperspace_cluster has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_implementation property.
# ccopt_refresh_schedule_before_implementation has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_mini_cluster property.
# ccopt_refresh_schedule_before_mini_cluster has default value.
## Tcl commands to replicate state of the ccopt_shared_legalizer_enable_legalize_on_move property.
# ccopt_shared_legalizer_enable_legalize_on_move has default value.
## Tcl commands to replicate state of the ccopt_speedup property.
# ccopt_speedup has default value.
## Tcl commands to replicate state of the ccopt_use_skew_clock property.
# ccopt_use_skew_clock has default value.
## Tcl commands to replicate state of the ccopt_worst_chain_report_timing_too property.
# ccopt_worst_chain_report_timing_too has default value.
## Tcl commands to replicate state of the cell_density property.
# cell_density has default value for all objects.
## Tcl commands to replicate state of the cell_halo_x property.
# cell_halo_x has default value for all objects.
## Tcl commands to replicate state of the cell_halo_y property.
# cell_halo_y has default value for all objects.
## Tcl commands to replicate state of the change_fences_to_guides property.
# change_fences_to_guides has default value.
## Tcl commands to replicate state of the channel_graph_ignore_routing_blockages_with_detour_smaller_than property.
# channel_graph_ignore_routing_blockages_with_detour_smaller_than has default value.
## Tcl commands to replicate state of the check_drive_strength_ordering_matches_area_ordering property.
# check_drive_strength_ordering_matches_area_ordering has default value.
## Tcl commands to replicate state of the check_prerequisites_check_place property.
# check_prerequisites_check_place has default value.
## Tcl commands to replicate state of the check_route_follows_guide property.
# check_route_follows_guide has default value.
## Tcl commands to replicate state of the check_route_follows_guide_min_length property.
# check_route_follows_guide_min_length has default value.
## Tcl commands to replicate state of the choose_aon_cell_by_bias_type property.
# choose_aon_cell_by_bias_type has default value.
## Tcl commands to replicate state of the chosen_route_type property.
# chosen_route_type has default value for all objects.
## Tcl commands to replicate state of the clean_up_start_of_nets property.
# clean_up_start_of_nets has default value.
## Tcl commands to replicate state of the clock_domain_skew_group property.
# clock_domain_skew_group has default value for all objects.
## Tcl commands to replicate state of the clock_gate_buffering_location property.
# clock_gate_buffering_location has default value for all objects.
## Tcl commands to replicate state of the clock_gating_cells property.
# clock_gating_cells has default value for all objects.
## Tcl commands to replicate state of the clock_nets_detailed_routed property.
set_ccopt_property clock_nets_detailed_routed 1
## Tcl commands to replicate state of the clock_period property.
set_ccopt_property clock_period -pin clk_p_i 10
## Tcl commands to replicate state of the clock_source_cells property.
# clock_source_cells has default value for all objects.
## Tcl commands to replicate state of the clock_spine_cell_do_not_flip property.
# clock_spine_cell_do_not_flip has default value.
## Tcl commands to replicate state of the clock_spine_cell_preserve_orient property.
# clock_spine_cell_preserve_orient has default value.
## Tcl commands to replicate state of the clock_tree_changes_use_scheduled_delete property.
# clock_tree_changes_use_scheduled_delete has default value.
## Tcl commands to replicate state of the clone_clock_gates property.
# clone_clock_gates has default value for all objects.
## Tcl commands to replicate state of the clone_clock_gates_band_size property.
# clone_clock_gates_band_size has default value.
## Tcl commands to replicate state of the clone_clock_gates_follow_parent_placement_restriction property.
# clone_clock_gates_follow_parent_placement_restriction has default value.
## Tcl commands to replicate state of the clone_clock_logic property.
# clone_clock_logic has default value for all objects.
## Tcl commands to replicate state of the cloned_gates_always_movable property.
# cloned_gates_always_movable has default value.
## Tcl commands to replicate state of the cloned_logics_always_movable property.
# cloned_logics_always_movable has default value.
## Tcl commands to replicate state of the cloned_power_management_cells_always_movable property.
# cloned_power_management_cells_always_movable has default value.
## Tcl commands to replicate state of the cloning_copy_activity property.
set_ccopt_property cloning_copy_activity 0
## Tcl commands to replicate state of the cloning_ignore_dont_touch_sdc property.
# cloning_ignore_dont_touch_sdc has default value.
## Tcl commands to replicate state of the cluster_agglom_balance_cap_pin_move_iterations property.
# cluster_agglom_balance_cap_pin_move_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_borderline_passing_threshold property.
# cluster_agglom_borderline_passing_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_bounding_box_limit_per_cluster property.
# cluster_agglom_bounding_box_limit_per_cluster has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_based_initial_k property.
# cluster_agglom_cap_based_initial_k has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_cost_exponent property.
# cluster_agglom_cap_cost_exponent has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_limit_per_cluster property.
# cluster_agglom_cap_limit_per_cluster has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_opt_level property.
# cluster_agglom_cap_opt_level has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_opt_mode property.
# cluster_agglom_cap_opt_mode has default value.
## Tcl commands to replicate state of the cluster_agglom_find_ideal_sink_location_in_region property.
# cluster_agglom_find_ideal_sink_location_in_region has default value.
## Tcl commands to replicate state of the cluster_agglom_find_ideal_sink_location_in_region_iterations property.
# cluster_agglom_find_ideal_sink_location_in_region_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine property.
# cluster_agglom_kmeans_refine has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_iterations property.
# cluster_agglom_kmeans_refine_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_split_limit property.
# cluster_agglom_kmeans_refine_split_limit has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_split_proportion property.
# cluster_agglom_kmeans_refine_split_proportion has default value.
## Tcl commands to replicate state of the cluster_agglom_max_neighbor_distance_to_radius_sum_ratio property.
# cluster_agglom_max_neighbor_distance_to_radius_sum_ratio has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement property.
# cluster_agglom_refinement has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_iterations property.
# cluster_agglom_refinement_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_non_slew_cap_target_threshold property.
# cluster_agglom_refinement_non_slew_cap_target_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_pin_move property.
# cluster_agglom_refinement_pin_move has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_pin_move_pin_cap_cost_weight property.
# cluster_agglom_refinement_pin_move_pin_cap_cost_weight has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_slew_to_cap_change_scaling_factor property.
# cluster_agglom_refinement_slew_to_cap_change_scaling_factor has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_and_merge property.
# cluster_agglom_refinement_split_and_merge has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_and_merge_frequency property.
# cluster_agglom_refinement_split_and_merge_frequency has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_only property.
# cluster_agglom_refinement_split_only has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_trigger_threshold property.
# cluster_agglom_refinement_trigger_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_run_single_iteration property.
# cluster_agglom_run_single_iteration has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering property.
# cluster_agglom_two_stage_global_clustering has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_balancing_iterations property.
# cluster_agglom_two_stage_global_clustering_balancing_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_flow_iterations property.
# cluster_agglom_two_stage_global_clustering_flow_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_pin_move_iterations property.
# cluster_agglom_two_stage_global_clustering_pin_move_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_verbose_level property.
# cluster_agglom_verbose_level has default value.
## Tcl commands to replicate state of the cluster_agglom_wire_cap_weight property.
# cluster_agglom_wire_cap_weight has default value.
## Tcl commands to replicate state of the cluster_algorithm property.
# cluster_algorithm has default value.
## Tcl commands to replicate state of the cluster_kmeans_calculate_k property.
# cluster_kmeans_calculate_k has default value.
## Tcl commands to replicate state of the cluster_kmeans_debug_tcl property.
# cluster_kmeans_debug_tcl has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters property.
# cluster_kmeans_fix_small_clusters has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters_limit property.
# cluster_kmeans_fix_small_clusters_limit has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters_max_iterations property.
# cluster_kmeans_fix_small_clusters_max_iterations has default value.
## Tcl commands to replicate state of the cluster_kmeans_get_min_clusters property.
# cluster_kmeans_get_min_clusters has default value.
## Tcl commands to replicate state of the cluster_kmeans_max_inner_iterations property.
# cluster_kmeans_max_inner_iterations has default value.
## Tcl commands to replicate state of the cluster_kmeans_new_rload_normalisation property.
# cluster_kmeans_new_rload_normalisation has default value.
## Tcl commands to replicate state of the cluster_kmeans_preserve_rload property.
# cluster_kmeans_preserve_rload has default value.
## Tcl commands to replicate state of the cluster_kmeans_split_limit property.
# cluster_kmeans_split_limit has default value.
## Tcl commands to replicate state of the cluster_kmeans_split_proportion property.
# cluster_kmeans_split_proportion has default value.
## Tcl commands to replicate state of the cluster_kmeans_trivial_increment_value property.
# cluster_kmeans_trivial_increment_value has default value.
## Tcl commands to replicate state of the cluster_when_starting_skewing property.
set_ccopt_property cluster_when_starting_skewing 0
## Tcl commands to replicate state of the clustering_agglom_cap_eval_use_cluster_weight property.
# clustering_agglom_cap_eval_use_cluster_weight has default value.
## Tcl commands to replicate state of the clustering_agglom_fix_can_cluster_accept_sink property.
# clustering_agglom_fix_can_cluster_accept_sink has default value.
## Tcl commands to replicate state of the clustering_agglom_levels property.
# clustering_agglom_levels has default value.
## Tcl commands to replicate state of the clustering_agglom_non_leaf_calculate_k property.
# clustering_agglom_non_leaf_calculate_k has default value.
## Tcl commands to replicate state of the clustering_agglom_non_leaf_cluster_algorithm property.
# clustering_agglom_non_leaf_cluster_algorithm has default value.
## Tcl commands to replicate state of the clustering_agglom_switch_to_kmeans_if_all_sinks_not_compatible property.
# clustering_agglom_switch_to_kmeans_if_all_sinks_not_compatible has default value.
## Tcl commands to replicate state of the clustering_avoid_adding_ccd_gates property.
# clustering_avoid_adding_ccd_gates has default value.
## Tcl commands to replicate state of the clustering_balance_stage_depths property.
# clustering_balance_stage_depths has default value.
## Tcl commands to replicate state of the clustering_calculate_stage_depths property.
# clustering_calculate_stage_depths has default value.
## Tcl commands to replicate state of the clustering_cap_based_evaluator_mode property.
# clustering_cap_based_evaluator_mode has default value.
## Tcl commands to replicate state of the clustering_caseb_make_progress_check property.
# clustering_caseb_make_progress_check has default value.
## Tcl commands to replicate state of the clustering_consider_cap_during_cluster_evaluation property.
# clustering_consider_cap_during_cluster_evaluation has default value.
## Tcl commands to replicate state of the clustering_consider_cap_for_cluster_acceptance property.
# clustering_consider_cap_for_cluster_acceptance has default value.
## Tcl commands to replicate state of the clustering_convert_pin_insertion_delays_to_stage_depth property.
# clustering_convert_pin_insertion_delays_to_stage_depth has default value.
## Tcl commands to replicate state of the clustering_debug_data property.
# clustering_debug_data has default value.
## Tcl commands to replicate state of the clustering_debug_plots property.
# clustering_debug_plots has default value.
## Tcl commands to replicate state of the clustering_downsizing property.
# clustering_downsizing has default value for all objects.
## Tcl commands to replicate state of the clustering_downsizing_stage_depth_limit property.
# clustering_downsizing_stage_depth_limit has default value for all objects.
## Tcl commands to replicate state of the clustering_fix_region_expansion_offsets property.
# clustering_fix_region_expansion_offsets has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing property.
# clustering_id_safe_downsizing has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_extra_unit_delays_factor property.
# clustering_id_safe_downsizing_extra_unit_delays_factor has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_inversion_unit_delay_factor property.
# clustering_id_safe_downsizing_inversion_unit_delay_factor has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_preserve_sinkinfo_flags property.
# clustering_id_safe_downsizing_preserve_sinkinfo_flags has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_stage_depth_limit property.
# clustering_id_safe_downsizing_stage_depth_limit has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_unit_delay_limit property.
# clustering_id_safe_downsizing_unit_delay_limit has default value.
## Tcl commands to replicate state of the clustering_id_safe_region_adjustment property.
# clustering_id_safe_region_adjustment has default value.
## Tcl commands to replicate state of the clustering_ignore_max_cap_computed_from_slew_target property.
# clustering_ignore_max_cap_computed_from_slew_target has default value.
## Tcl commands to replicate state of the clustering_input_transition_modeling_scale_factor property.
# clustering_input_transition_modeling_scale_factor has default value.
## Tcl commands to replicate state of the clustering_length_based_max_cap_scaling_factor property.
# clustering_length_based_max_cap_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_length_based_max_radius_scaling_factor property.
# clustering_length_based_max_radius_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_max_cap_target_factor property.
# clustering_max_cap_target_factor has default value.
## Tcl commands to replicate state of the clustering_max_radius_target property.
# clustering_max_radius_target has default value.
## Tcl commands to replicate state of the clustering_mix_inverters_and_buffers property.
# clustering_mix_inverters_and_buffers has default value.
## Tcl commands to replicate state of the clustering_mix_inverters_and_buffers_match_cell_instances property.
# clustering_mix_inverters_and_buffers_match_cell_instances has default value.
## Tcl commands to replicate state of the clustering_only_consider_cap_target property.
# clustering_only_consider_cap_target has default value.
## Tcl commands to replicate state of the clustering_only_consider_cap_target_levels property.
# clustering_only_consider_cap_target_levels has default value.
## Tcl commands to replicate state of the clustering_partition_sinks_using_agglom property.
# clustering_partition_sinks_using_agglom has default value.
## Tcl commands to replicate state of the clustering_partition_sinks_using_agglom_use_two_stage property.
# clustering_partition_sinks_using_agglom_use_two_stage has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit property.
# clustering_per_stage_total_delay_limit has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_clock_gates property.
# clustering_per_stage_total_delay_limit_clock_gates has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_clock_logic property.
# clustering_per_stage_total_delay_limit_clock_logic has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_drivers property.
# clustering_per_stage_total_delay_limit_drivers has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_transitively property.
# clustering_per_stage_total_delay_limit_transitively has default value.
## Tcl commands to replicate state of the clustering_per_stage_wire_delay_limit property.
# clustering_per_stage_wire_delay_limit has default value.
## Tcl commands to replicate state of the clustering_region property.
# clustering_region has default value for all objects.
## Tcl commands to replicate state of the clustering_region_expansion_downsize_commit_change property.
# clustering_region_expansion_downsize_commit_change has default value.
## Tcl commands to replicate state of the clustering_region_expansion_downsize_first property.
# clustering_region_expansion_downsize_first has default value.
## Tcl commands to replicate state of the clustering_region_expansion_use_route property.
# clustering_region_expansion_use_route has default value.
## Tcl commands to replicate state of the clustering_region_expansion_use_route_expand_beyond property.
# clustering_region_expansion_use_route_expand_beyond has default value.
## Tcl commands to replicate state of the clustering_resolve_user_module_before_finding_legal_location property.
# clustering_resolve_user_module_before_finding_legal_location has default value.
## Tcl commands to replicate state of the clustering_size_based_trivial_increment property.
# clustering_size_based_trivial_increment has default value.
## Tcl commands to replicate state of the clustering_skip_mix_inverters_and_buffers_under_icg property.
# clustering_skip_mix_inverters_and_buffers_under_icg has default value.
## Tcl commands to replicate state of the clustering_source_group_assign_fanout_by_distance_only property.
# clustering_source_group_assign_fanout_by_distance_only has default value.
## Tcl commands to replicate state of the clustering_source_group_clear_movement_limit property.
# clustering_source_group_clear_movement_limit has default value.
## Tcl commands to replicate state of the clustering_source_group_debug_file_directory property.
# clustering_source_group_debug_file_directory has default value.
## Tcl commands to replicate state of the clustering_source_group_distance_metric property.
# clustering_source_group_distance_metric has default value.
## Tcl commands to replicate state of the clustering_source_group_icg_aware_assignment property.
# clustering_source_group_icg_aware_assignment has default value.
## Tcl commands to replicate state of the clustering_source_group_icg_driving_distance property.
# clustering_source_group_icg_driving_distance has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_icg_driving_distances property.
# clustering_source_group_icg_driving_distances has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_cloned_fraction property.
# clustering_source_group_max_cloned_fraction has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_sink_per_tap property.
# clustering_source_group_max_sink_per_tap has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_sink_per_tap_ratio property.
# clustering_source_group_max_sink_per_tap_ratio has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_min_sink_per_tap_ratio property.
# clustering_source_group_min_sink_per_tap_ratio has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_optimization_effort property.
# clustering_source_group_optimization_effort has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_single_root_sink_assignment_warning_threshold property.
# clustering_source_group_single_root_sink_assignment_warning_threshold has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_when_to_implement property.
# clustering_source_group_when_to_implement has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions property.
# clustering_tighten_input_transitions has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_at_clock_root_fanout property.
# clustering_tighten_input_transitions_at_clock_root_fanout has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_pre_char_distance_factor property.
# clustering_tighten_input_transitions_pre_char_distance_factor has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_pre_char_fanout_factor property.
# clustering_tighten_input_transitions_pre_char_fanout_factor has default value.
## Tcl commands to replicate state of the clustering_unit_wire_cap_scaling_factor property.
# clustering_unit_wire_cap_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_use_agglom_cap_evaluator property.
# clustering_use_agglom_cap_evaluator has default value.
## Tcl commands to replicate state of the clustering_use_disjoint_region_count_for_expanding_regions property.
# clustering_use_disjoint_region_count_for_expanding_regions has default value.
## Tcl commands to replicate state of the clustering_user_max_cap_target property.
# clustering_user_max_cap_target has default value.
## Tcl commands to replicate state of the clustering_with_clones_fallback_to_buffering property.
# clustering_with_clones_fallback_to_buffering has default value.
## Tcl commands to replicate state of the compatibility_warning property.
# compatibility_warning has default value.
## Tcl commands to replicate state of the congested_rectangles property.
# congested_rectangles has default value.
## Tcl commands to replicate state of the congestion_override property.
# congestion_override has default value for all objects.
## Tcl commands to replicate state of the congestion_override_for_clustering property.
# congestion_override_for_clustering has default value for all objects.
## Tcl commands to replicate state of the consider_approximate_delay_of_cell_in_sizing property.
# consider_approximate_delay_of_cell_in_sizing has default value.
## Tcl commands to replicate state of the consider_bus_ports_dont_touch property.
# consider_bus_ports_dont_touch has default value.
## Tcl commands to replicate state of the consider_during_latency_update property.
# consider_during_latency_update has default value for all objects.
## Tcl commands to replicate state of the consider_em_constraints property.
# consider_em_constraints has default value.
## Tcl commands to replicate state of the consider_em_distance_factor property.
# consider_em_distance_factor has default value.
## Tcl commands to replicate state of the consider_liberty_pin_max_trans property.
# consider_liberty_pin_max_trans has default value.
## Tcl commands to replicate state of the consider_power_management property.
# consider_power_management has default value.
## Tcl commands to replicate state of the consider_restricted_placement_region_during_upsizing property.
# consider_restricted_placement_region_during_upsizing has default value.
## Tcl commands to replicate state of the consider_unbufferable_siblings_in_case_h property.
# consider_unbufferable_siblings_in_case_h has default value.
## Tcl commands to replicate state of the constrain_for_right_size_after_delay property.
# constrain_for_right_size_after_delay has default value.
## Tcl commands to replicate state of the constrain_output_pin_max_trans property.
# constrain_output_pin_max_trans has default value.
## Tcl commands to replicate state of the constrained_node_delay_cache_max_size property.
# constrained_node_delay_cache_max_size has default value.
## Tcl commands to replicate state of the constrained_node_transform_cache_max_size property.
# constrained_node_transform_cache_max_size has default value.
## Tcl commands to replicate state of the constrains property.
# constrains has default value for all objects.
## Tcl commands to replicate state of the convert_pin_insertion_delays_to_stage_depth property.
# convert_pin_insertion_delays_to_stage_depth has default value.
## Tcl commands to replicate state of the convert_special_wires property.
# convert_special_wires has default value.
## Tcl commands to replicate state of the create_route_guides_for_two_term_nets property.
# create_route_guides_for_two_term_nets has default value.
## Tcl commands to replicate state of the ctd_debug_always_show_windows property.
# ctd_debug_always_show_windows has default value.
## Tcl commands to replicate state of the ctd_debug_min_object_count property.
# ctd_debug_min_object_count has default value.
## Tcl commands to replicate state of the ctd_debug_min_sink_count property.
# ctd_debug_min_sink_count has default value.
## Tcl commands to replicate state of the ctd_debug_skip_path_timing property.
# ctd_debug_skip_path_timing has default value.
## Tcl commands to replicate state of the cte_identify_clock_tree_incremental_mode property.
# cte_identify_clock_tree_incremental_mode has default value.
## Tcl commands to replicate state of the cts_binary_chop_to_validate_cell_lists property.
# cts_binary_chop_to_validate_cell_lists has default value.
## Tcl commands to replicate state of the cts_clock_gate_movement_limit property.
# cts_clock_gate_movement_limit has default value.
## Tcl commands to replicate state of the cts_critical_capture_pin property.
# cts_critical_capture_pin has default value for all objects.
## Tcl commands to replicate state of the cts_critical_capture_slew property.
# cts_critical_capture_slew has default value for all objects.
## Tcl commands to replicate state of the cts_critical_launch_load property.
# cts_critical_launch_load has default value for all objects.
## Tcl commands to replicate state of the cts_critical_launch_pin property.
# cts_critical_launch_pin has default value for all objects.
## Tcl commands to replicate state of the cts_def_lock_clock_network_after_resynthesis property.
# cts_def_lock_clock_network_after_resynthesis has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks property.
# cts_def_lock_clock_sinks has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks_after_routing property.
# cts_def_lock_clock_sinks_after_routing has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks_at_ccopt_engine_destroy property.
# cts_def_lock_clock_sinks_at_ccopt_engine_destroy has default value.
## Tcl commands to replicate state of the cts_edge_sensitivity property.
# cts_edge_sensitivity has default value for all objects.
## Tcl commands to replicate state of the cts_enable_generator_path_fragments property.
# cts_enable_generator_path_fragments has default value.
## Tcl commands to replicate state of the cts_force_clock_objects_to_propagated property.
# cts_force_clock_objects_to_propagated has default value.
## Tcl commands to replicate state of the cts_isolated property.
# cts_isolated has default value for all objects.
## Tcl commands to replicate state of the cts_legalizer_allow_fgc property.
# cts_legalizer_allow_fgc has default value.
## Tcl commands to replicate state of the cts_legalizer_allow_high_effort property.
# cts_legalizer_allow_high_effort has default value.
## Tcl commands to replicate state of the cts_max_driver_height property.
# cts_max_driver_height has default value.
## Tcl commands to replicate state of the cts_max_thread_override property.
set_ccopt_property cts_max_thread_override auto
## Tcl commands to replicate state of the cts_merge_clock_gates property.
# cts_merge_clock_gates has default value for all objects.
## Tcl commands to replicate state of the cts_merge_clock_gates_vertically property.
# cts_merge_clock_gates_vertically has default value.
## Tcl commands to replicate state of the cts_merge_clock_logic property.
# cts_merge_clock_logic has default value for all objects.
## Tcl commands to replicate state of the cts_multi_corner_sink_type property.
# cts_multi_corner_sink_type has default value.
## Tcl commands to replicate state of the cts_multi_corner_slew_targets property.
# cts_multi_corner_slew_targets has default value.
## Tcl commands to replicate state of the cts_multi_sink_node_to_node_fragments property.
# cts_multi_sink_node_to_node_fragments has default value.
## Tcl commands to replicate state of the cts_relax_skew_target property.
# cts_relax_skew_target has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_ratio property.
# cts_relax_skew_target_ratio has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_ratio_low property.
# cts_relax_skew_target_ratio_low has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_restore property.
# cts_relax_skew_target_restore has default value.
## Tcl commands to replicate state of the cts_route_buffering_allow_preserved_ports property.
# cts_route_buffering_allow_preserved_ports has default value.
## Tcl commands to replicate state of the cts_route_buffering_allow_preserved_ports_on_ilm_nets property.
# cts_route_buffering_allow_preserved_ports_on_ilm_nets has default value.
## Tcl commands to replicate state of the cts_route_buffering_draw_svg property.
# cts_route_buffering_draw_svg has default value.
## Tcl commands to replicate state of the cts_route_buffering_export_topology property.
# cts_route_buffering_export_topology has default value.
## Tcl commands to replicate state of the cts_route_buffering_include_root_in_timing property.
# cts_route_buffering_include_root_in_timing has default value.
## Tcl commands to replicate state of the cts_route_buffering_include_sinks_in_timing property.
# cts_route_buffering_include_sinks_in_timing has default value.
## Tcl commands to replicate state of the cts_route_buffering_loose_skew_margin_multiplier property.
# cts_route_buffering_loose_skew_margin_multiplier has default value.
## Tcl commands to replicate state of the cts_route_buffering_max_merged_solutions property.
# cts_route_buffering_max_merged_solutions has default value.
## Tcl commands to replicate state of the cts_route_buffering_split_branch_and_buffer property.
# cts_route_buffering_split_branch_and_buffer has default value.
## Tcl commands to replicate state of the cts_routing_estimate_spread_nodes property.
# cts_routing_estimate_spread_nodes has default value.
## Tcl commands to replicate state of the cts_share_global_timing_engine property.
# cts_share_global_timing_engine has default value.
## Tcl commands to replicate state of the cts_split_run_trial property.
# cts_split_run_trial has default value.
## Tcl commands to replicate state of the cts_unfixable_overload_use_override_targets property.
# cts_unfixable_overload_use_override_targets has default value.
## Tcl commands to replicate state of the cts_use_sp_ideal_orientation property.
# cts_use_sp_ideal_orientation has default value.
## Tcl commands to replicate state of the debug_cong_repair_after_clustering property.
# debug_cong_repair_after_clustering has default value.
## Tcl commands to replicate state of the debug_locks_on_large_legalizer_difference property.
# debug_locks_on_large_legalizer_difference has default value.
## Tcl commands to replicate state of the debug_log_errors_during_ccopt_restore property.
# debug_log_errors_during_ccopt_restore has default value.
## Tcl commands to replicate state of the debug_saved_ccopt_state_to_dir property.
# debug_saved_ccopt_state_to_dir has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_designobject_uid_list property.
# debug_stacktrace_on_designobject_uid_list has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_length property.
# debug_stacktrace_on_length has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_netlist_object_fhn_list property.
# debug_stacktrace_on_netlist_object_fhn_list has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_uid_list property.
# debug_stacktrace_on_uid_list has default value.
## Tcl commands to replicate state of the debug_stage_delays_for_nodes property.
# debug_stage_delays_for_nodes has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_leaf_net property.
# default_prim_dijkstra_factor_for_clustering_leaf_net has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_top_net property.
# default_prim_dijkstra_factor_for_clustering_top_net has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_trunk_net property.
# default_prim_dijkstra_factor_for_clustering_trunk_net has default value.
## Tcl commands to replicate state of the define_clock_tree_release_nonclock_gates_patch property.
# define_clock_tree_release_nonclock_gates_patch has default value.
## Tcl commands to replicate state of the degenerate_routing_estimate_cap_factor property.
# degenerate_routing_estimate_cap_factor has default value.
## Tcl commands to replicate state of the degrade_asserted_transition property.
# degrade_asserted_transition has default value.
## Tcl commands to replicate state of the delay_cells property.
# delay_cells has default value for all objects.
## Tcl commands to replicate state of the detach_gates_iterate_over_all_hnets_in_hinst property.
# detach_gates_iterate_over_all_hnets_in_hinst has default value.
## Tcl commands to replicate state of the detailed_balance_max_drive_cell property.
# detailed_balance_max_drive_cell has default value.
## Tcl commands to replicate state of the detailed_cell_warnings property.
# detailed_cell_warnings has default value.
## Tcl commands to replicate state of the detailed_final_ignore_exclusion property.
# detailed_final_ignore_exclusion has default value.
## Tcl commands to replicate state of the diag_on_non_fatal_assert property.
# diag_on_non_fatal_assert has default value.
## Tcl commands to replicate state of the disable_cell_renaming property.
# disable_cell_renaming has default value.
## Tcl commands to replicate state of the disable_timing_arc_across_ilm_boundary property.
# disable_timing_arc_across_ilm_boundary has default value.
## Tcl commands to replicate state of the distance_from_locked_parent_restriction property.
# distance_from_locked_parent_restriction has default value for all objects.
## Tcl commands to replicate state of the distance_from_locked_parent_restriction_calculation_uses_all_cells property.
# distance_from_locked_parent_restriction_calculation_uses_all_cells has default value.
## Tcl commands to replicate state of the dont_commit_attributes_more_than_once property.
# dont_commit_attributes_more_than_once has default value.
## Tcl commands to replicate state of the dont_touch_non_flop_clock_gating_treat_latches_as_flops property.
# dont_touch_non_flop_clock_gating_treat_latches_as_flops has default value.
## Tcl commands to replicate state of the down_skew_band_size_ideal_mode property.
# down_skew_band_size_ideal_mode has default value.
## Tcl commands to replicate state of the driver_levels property.
## Tcl commands to replicate state of the driver_movement_limit property.
# driver_movement_limit has default value.
## Tcl commands to replicate state of the early_global_layer_relax property.
# early_global_layer_relax has default value.
## Tcl commands to replicate state of the early_global_layer_relax_ratio property.
# early_global_layer_relax_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_congestion_ratio property.
# early_global_leaf_congestion_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_rows_per_gcell property.
# early_global_leaf_rows_per_gcell has default value.
## Tcl commands to replicate state of the early_global_leaf_scenic_ratio property.
# early_global_leaf_scenic_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_source_sink_ratio property.
# early_global_leaf_source_sink_ratio has default value.
## Tcl commands to replicate state of the early_global_route_guide_align_to_gcell_centers property.
# early_global_route_guide_align_to_gcell_centers has default value.
## Tcl commands to replicate state of the early_global_route_guide_min_downstream_wirelength property.
# early_global_route_guide_min_downstream_wirelength has default value.
## Tcl commands to replicate state of the early_global_route_guide_pruning_method property.
# early_global_route_guide_pruning_method has default value.
## Tcl commands to replicate state of the early_global_trunk_congestion_ratio property.
# early_global_trunk_congestion_ratio has default value.
## Tcl commands to replicate state of the early_global_trunk_rows_per_gcell property.
# early_global_trunk_rows_per_gcell has default value.
## Tcl commands to replicate state of the early_global_trunk_scenic_ratio property.
# early_global_trunk_scenic_ratio has default value.
## Tcl commands to replicate state of the early_global_trunk_source_sink_ratio property.
# early_global_trunk_source_sink_ratio has default value.
## Tcl commands to replicate state of the early_global_use_existing_estimate_as_guide property.
# early_global_use_existing_estimate_as_guide has default value.
## Tcl commands to replicate state of the echo_sylog_to_debug property.
# echo_sylog_to_debug has default value.
## Tcl commands to replicate state of the effective_distance_from_locked_parent_restriction property.
# effective_distance_from_locked_parent_restriction has default value for all objects.
## Tcl commands to replicate state of the egrpc_agglom_clustering_ratio_threshold property.
# egrpc_agglom_clustering_ratio_threshold has default value.
## Tcl commands to replicate state of the egrpc_call_refine_place_in_loop property.
# egrpc_call_refine_place_in_loop has default value.
## Tcl commands to replicate state of the egrpc_clone_and_divide_overslew_threshold property.
# egrpc_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the egrpc_downsize_algorithm_passes property.
# egrpc_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the egrpc_downsize_algorithm_use_single_step property.
# egrpc_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the egrpc_downsize_slew_target_multiplier property.
# egrpc_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the egrpc_downsize_with_cloning property.
# egrpc_downsize_with_cloning has default value.
## Tcl commands to replicate state of the egrpc_drv_buffering_number_to_keep property.
# egrpc_drv_buffering_number_to_keep has default value.
## Tcl commands to replicate state of the egrpc_drv_buffering_second_pass_number_to_keep property.
# egrpc_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the egrpc_enable property.
# egrpc_enable has default value.
## Tcl commands to replicate state of the egrpc_enable_agglom_clustering property.
# egrpc_enable_agglom_clustering has default value.
## Tcl commands to replicate state of the egrpc_enable_clone_and_divide property.
# egrpc_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the egrpc_enable_congestion_repair property.
# egrpc_enable_congestion_repair has default value.
## Tcl commands to replicate state of the egrpc_enable_down_sizing_pass property.
# egrpc_enable_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_by_rebuffering property.
# egrpc_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_by_rebuffering_second_pass property.
# egrpc_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_with_restructuring property.
# egrpc_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_initial_sizing property.
# egrpc_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_down_sizing_pass property.
# egrpc_enable_initial_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_fixing_long_paths property.
# egrpc_enable_initial_fixing_long_paths has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_move_for_pin_access property.
# egrpc_enable_initial_move_for_pin_access has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_refine_place property.
# egrpc_enable_initial_refine_place has default value.
## Tcl commands to replicate state of the egrpc_enable_max_length_checks property.
# egrpc_enable_max_length_checks has default value.
## Tcl commands to replicate state of the egrpc_enable_move_down property.
# egrpc_enable_move_down has default value.
## Tcl commands to replicate state of the egrpc_enable_move_for_pin_access property.
# egrpc_enable_move_for_pin_access has default value.
## Tcl commands to replicate state of the egrpc_enable_move_to_geodesic_center property.
# egrpc_enable_move_to_geodesic_center has default value.
## Tcl commands to replicate state of the egrpc_enable_prim_dijkstra_adjust property.
# egrpc_enable_prim_dijkstra_adjust has default value.
## Tcl commands to replicate state of the egrpc_enable_routing_correlation_report property.
# egrpc_enable_routing_correlation_report has default value.
## Tcl commands to replicate state of the egrpc_enable_skew_fixing_by_cell_sizing property.
# egrpc_enable_skew_fixing_by_cell_sizing has default value.
## Tcl commands to replicate state of the egrpc_enable_skew_fixing_by_rebuffering property.
# egrpc_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the egrpc_final_down_sizing_pass property.
# egrpc_final_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_loop_limit property.
# egrpc_loop_limit has default value.
## Tcl commands to replicate state of the egrpc_max_move_multiplier property.
# egrpc_max_move_multiplier has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_buffering_in_ps property.
# egrpc_min_overslew_to_fix_using_buffering_in_ps has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_buffering_second_pass_in_ps property.
# egrpc_min_overslew_to_fix_using_buffering_second_pass_in_ps has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_sizing_in_ps property.
# egrpc_min_overslew_to_fix_using_sizing_in_ps has default value.
## Tcl commands to replicate state of the egrpc_update_timing property.
# egrpc_update_timing has default value.
## Tcl commands to replicate state of the egrpc_use_fast_cell_sizing_algorithm property.
# egrpc_use_fast_cell_sizing_algorithm has default value.
## Tcl commands to replicate state of the egrpc_write_extra_dag_stats property.
# egrpc_write_extra_dag_stats has default value.
## Tcl commands to replicate state of the em_constraints_target_max_cap_pin_cap_factor property.
# em_constraints_target_max_cap_pin_cap_factor has default value.
## Tcl commands to replicate state of the enable_adjacent_cell_color_checks property.
# enable_adjacent_cell_color_checks has default value.
## Tcl commands to replicate state of the enable_all_views_for_io_latency_update property.
# enable_all_views_for_io_latency_update has default value.
## Tcl commands to replicate state of the enable_assert_single_threaded property.
# enable_assert_single_threaded has default value.
## Tcl commands to replicate state of the enable_channel_graph_line_coverage property.
# enable_channel_graph_line_coverage has default value.
## Tcl commands to replicate state of the enable_clustering_multithreaded property.
# enable_clustering_multithreaded has default value.
## Tcl commands to replicate state of the enable_constraints_from_xhinsts property.
# enable_constraints_from_xhinsts has default value.
## Tcl commands to replicate state of the enable_correlation_report_extra_stats property.
# enable_correlation_report_extra_stats has default value.
## Tcl commands to replicate state of the enable_downstream_net_route_invalidation property.
# enable_downstream_net_route_invalidation has default value.
## Tcl commands to replicate state of the enable_evaluate_cluster_cache property.
# enable_evaluate_cluster_cache has default value.
## Tcl commands to replicate state of the enable_flop_merge_split_support property.
# enable_flop_merge_split_support has default value.
## Tcl commands to replicate state of the enable_globalupdate_multithreaded property.
# enable_globalupdate_multithreaded has default value.
## Tcl commands to replicate state of the enable_implementation property.
# enable_implementation has default value.
## Tcl commands to replicate state of the enable_initial_clustering property.
# enable_initial_clustering has default value.
## Tcl commands to replicate state of the enable_invalidate_timing_after_resynth property.
# enable_invalidate_timing_after_resynth has default value.
## Tcl commands to replicate state of the enable_latch_sta_updates property.
# enable_latch_sta_updates has default value.
## Tcl commands to replicate state of the enable_legacy_cts_metric_reporting property.
# enable_legacy_cts_metric_reporting has default value.
## Tcl commands to replicate state of the enable_locked_node_check_failure property.
# enable_locked_node_check_failure has default value.
## Tcl commands to replicate state of the enable_movegate_multithreaded property.
# enable_movegate_multithreaded has default value.
## Tcl commands to replicate state of the enable_movegates_multithreaded property.
# enable_movegates_multithreaded has default value.
## Tcl commands to replicate state of the enable_nanoroute_layer_check_failure property.
# enable_nanoroute_layer_check_failure has default value.
## Tcl commands to replicate state of the enable_new_stage_depth_counting property.
# enable_new_stage_depth_counting has default value.
## Tcl commands to replicate state of the enable_pathoptimization_multithreaded property.
# enable_pathoptimization_multithreaded has default value.
## Tcl commands to replicate state of the enable_power_analysis property.
# enable_power_analysis has default value.
## Tcl commands to replicate state of the enable_primdijkstra_xgraph_dump property.
# enable_primdijkstra_xgraph_dump has default value.
## Tcl commands to replicate state of the enable_pro_multithreaded property.
# enable_pro_multithreaded has default value.
## Tcl commands to replicate state of the enable_ratchet_detailed_balancer property.
# enable_ratchet_detailed_balancer has default value.
## Tcl commands to replicate state of the enable_resizegate_multithreaded property.
# enable_resizegate_multithreaded has default value.
## Tcl commands to replicate state of the enable_resizegates_multithreaded property.
# enable_resizegates_multithreaded has default value.
## Tcl commands to replicate state of the enable_resynthesis_correlation_report property.
# enable_resynthesis_correlation_report has default value.
## Tcl commands to replicate state of the enable_routing_correlation_report property.
# enable_routing_correlation_report has default value.
## Tcl commands to replicate state of the enable_timing_chain_manager_in_ccopt_design property.
# enable_timing_chain_manager_in_ccopt_design has default value.
## Tcl commands to replicate state of the enable_worst_chain_report_in_ccopt_design property.
# enable_worst_chain_report_in_ccopt_design has default value.
## Tcl commands to replicate state of the ensure_connected_rc_net property.
# ensure_connected_rc_net has default value.
## Tcl commands to replicate state of the equalize_net_lengths property.
# equalize_net_lengths has default value for all objects.
## Tcl commands to replicate state of the estimate_to_detailed_route_capacitance_scaling_factor property.
# estimate_to_detailed_route_capacitance_scaling_factor has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_capacitance_scaling_factor_applied property.
# estimate_to_detailed_route_capacitance_scaling_factor_applied has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_resistance_scaling_factor property.
# estimate_to_detailed_route_resistance_scaling_factor has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_resistance_scaling_factor_applied property.
# estimate_to_detailed_route_resistance_scaling_factor_applied has default value.
## Tcl commands to replicate state of the exclude_delays_below_sinks property.
# exclude_delays_below_sinks has default value for all objects.
## Tcl commands to replicate state of the exclusive_sinks_rank property.
# exclusive_sinks_rank has default value for all objects.
## Tcl commands to replicate state of the exit_if_trial_balance_delay_estimation_high property.
# exit_if_trial_balance_delay_estimation_high has default value.
## Tcl commands to replicate state of the exp_advanced_early_global_guide property.
# exp_advanced_early_global_guide has default value.
## Tcl commands to replicate state of the exp_buffer_fanout_in_reducing_insertion_delay_2_offload_driver_only property.
# exp_buffer_fanout_in_reducing_insertion_delay_2_offload_driver_only has default value.
## Tcl commands to replicate state of the exp_buffer_fanout_in_reducing_insertion_delay_2_root_branch_point_only property.
# exp_buffer_fanout_in_reducing_insertion_delay_2_root_branch_point_only has default value.
## Tcl commands to replicate state of the exp_clustering_put_driver_in_center_of_fanout_method property.
# exp_clustering_put_driver_in_center_of_fanout_method has default value.
## Tcl commands to replicate state of the exp_egrpc_refine_place_method property.
# exp_egrpc_refine_place_method has default value.
## Tcl commands to replicate state of the exp_egrpc_refine_place_soft_fix_clock_sinks property.
# exp_egrpc_refine_place_soft_fix_clock_sinks has default value.
## Tcl commands to replicate state of the exp_egrpc_refine_place_uses_zero_halos_for_sinks property.
# exp_egrpc_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_enable_nsigma_transition_model property.
# exp_enable_nsigma_transition_model has default value.
## Tcl commands to replicate state of the exp_extract_implicit_stop_pin_at_trigger_arc property.
# exp_extract_implicit_stop_pin_at_trigger_arc has default value.
## Tcl commands to replicate state of the exp_faster_run_time_in_timing property.
# exp_faster_run_time_in_timing has default value.
## Tcl commands to replicate state of the exp_faster_run_time_in_timing_until_clustering property.
# exp_faster_run_time_in_timing_until_clustering has default value.
## Tcl commands to replicate state of the exp_fix_early_global_pin_connection_fix property.
# exp_fix_early_global_pin_connection_fix has default value.
## Tcl commands to replicate state of the exp_flex_h_refine_place_uses_zero_halos_for_sinks property.
# exp_flex_h_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_flexible_htree_layer_demote_distance property.
# exp_flexible_htree_layer_demote_distance has default value for all objects.
## Tcl commands to replicate state of the exp_flexible_htree_preferred_routing_layer_effort property.
# exp_flexible_htree_preferred_routing_layer_effort has default value.
## Tcl commands to replicate state of the exp_flexible_htree_refine_place_method property.
# exp_flexible_htree_refine_place_method has default value.
## Tcl commands to replicate state of the exp_force_cluster_only_legalize_clock_trees property.
# exp_force_cluster_only_legalize_clock_trees has default value.
## Tcl commands to replicate state of the exp_igpc_refine_place_method property.
# exp_igpc_refine_place_method has default value.
## Tcl commands to replicate state of the exp_igpc_refine_place_uses_zero_halos_for_sinks property.
# exp_igpc_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_local_wire_reclaim_after_cts property.
# exp_local_wire_reclaim_after_cts has default value.
## Tcl commands to replicate state of the exp_local_wire_reclaim_after_postcts property.
# exp_local_wire_reclaim_after_postcts has default value.
## Tcl commands to replicate state of the exp_multi_tap_clone_power_domain_boundary_cells property.
# exp_multi_tap_clone_power_domain_boundary_cells has default value.
## Tcl commands to replicate state of the exp_multi_tap_clone_power_management_cells property.
# exp_multi_tap_clone_power_management_cells has default value.
## Tcl commands to replicate state of the exp_position_logics_near_multitap_parents property.
# exp_position_logics_near_multitap_parents has default value.
## Tcl commands to replicate state of the exp_post_clustering_refine_place_preprocessing_type property.
# exp_post_clustering_refine_place_preprocessing_type has default value.
## Tcl commands to replicate state of the exp_post_clustering_refine_place_uses_zero_halos_for_sinks property.
# exp_post_clustering_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_post_conditioning_enable_final_dag_stats property.
# exp_post_conditioning_enable_final_dag_stats has default value.
## Tcl commands to replicate state of the exp_post_conditioning_refine_place_method property.
# exp_post_conditioning_refine_place_method has default value.
## Tcl commands to replicate state of the exp_post_conditioning_refine_place_soft_fix_clock_sinks property.
# exp_post_conditioning_refine_place_soft_fix_clock_sinks has default value.
## Tcl commands to replicate state of the exp_post_conditioning_refine_place_uses_zero_halos_for_sinks property.
# exp_post_conditioning_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_post_implementation_refine_place_uses_zero_halos_for_sinks property.
# exp_post_implementation_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_pro_refine_place_method property.
# exp_pro_refine_place_method has default value.
## Tcl commands to replicate state of the exp_pro_refine_place_uses_zero_halos_for_sinks property.
# exp_pro_refine_place_uses_zero_halos_for_sinks has default value.
## Tcl commands to replicate state of the exp_refine_place_method_at_the_end_of_clustering property.
# exp_refine_place_method_at_the_end_of_clustering has default value.
## Tcl commands to replicate state of the exp_refine_place_method_at_the_end_of_implementation property.
# exp_refine_place_method_at_the_end_of_implementation has default value.
## Tcl commands to replicate state of the exp_refine_place_soft_fix_clock_cells property.
# exp_refine_place_soft_fix_clock_cells has default value.
## Tcl commands to replicate state of the exp_refine_place_soft_fix_clock_sinks_at_the_end_of_implementation property.
# exp_refine_place_soft_fix_clock_sinks_at_the_end_of_implementation has default value.
## Tcl commands to replicate state of the exp_relax_skew_target_unit_delay_multiplier property.
# exp_relax_skew_target_unit_delay_multiplier has default value.
## Tcl commands to replicate state of the exp_routing_estimate_aggressive_pin_escape property.
# exp_routing_estimate_aggressive_pin_escape has default value.
## Tcl commands to replicate state of the exp_routing_estimate_fast_post_routing_fix property.
# exp_routing_estimate_fast_post_routing_fix has default value.
## Tcl commands to replicate state of the exp_routing_estimate_similar_topology_routing_fast property.
# exp_routing_estimate_similar_topology_routing_fast has default value.
## Tcl commands to replicate state of the exp_routing_estimate_skip_3d_blockage_violation_free_nets property.
# exp_routing_estimate_skip_3d_blockage_violation_free_nets has default value.
## Tcl commands to replicate state of the exp_routing_estimate_skip_must_layer_relax_segments property.
# exp_routing_estimate_skip_must_layer_relax_segments has default value.
## Tcl commands to replicate state of the exp_routing_estimate_use_eg_blk_vio_check_on_edge property.
# exp_routing_estimate_use_eg_blk_vio_check_on_edge has default value.
## Tcl commands to replicate state of the exp_save_clock_trees_in_dag_order property.
# exp_save_clock_trees_in_dag_order has default value.
## Tcl commands to replicate state of the exp_timing_enable_predictive_cache property.
# exp_timing_enable_predictive_cache has default value.
## Tcl commands to replicate state of the exp_use_high_frequency_detailed_router property.
# exp_use_high_frequency_detailed_router has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_initial_global_use_max_delay property.
# exp_useful_skew_ideal_mode_initial_global_use_max_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_initial_global_use_max_delay property.
# exp_useful_skew_initial_global_use_max_delay has default value.
## Tcl commands to replicate state of the expand_multi_child_regions property.
# expand_multi_child_regions has default value for all objects.
## Tcl commands to replicate state of the expand_multi_child_regions_above property.
# expand_multi_child_regions_above has default value for all objects.
## Tcl commands to replicate state of the expand_multi_child_regions_for_furthest_sinks property.
# expand_multi_child_regions_for_furthest_sinks has default value.
## Tcl commands to replicate state of the expand_multi_child_regions_for_sinks_with_min_depth property.
# expand_multi_child_regions_for_sinks_with_min_depth has default value.
## Tcl commands to replicate state of the extract_additional_clock_tree_symbols property.
# extract_additional_clock_tree_symbols has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_delete_temp_files property.
# extract_clock_trees_ilm_flow_delete_temp_files has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_run_with_fork property.
# extract_clock_trees_ilm_flow_run_with_fork has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_run_with_propagated_clocks property.
# extract_clock_trees_ilm_flow_run_with_propagated_clocks has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_use_skew_group_delays property.
# extract_clock_trees_ilm_flow_use_skew_group_delays has default value.
## Tcl commands to replicate state of the extract_clock_trees_use_ilm_flow property.
# extract_clock_trees_use_ilm_flow has default value.
## Tcl commands to replicate state of the extract_create_explicit_ignores_for_implicit_excludes_beyond_sta_clock_network property.
# extract_create_explicit_ignores_for_implicit_excludes_beyond_sta_clock_network has default value.
## Tcl commands to replicate state of the extract_ilm_fanout_limit property.
# extract_ilm_fanout_limit has default value.
## Tcl commands to replicate state of the extract_minimize_generated_clock_insertion_delay property.
# extract_minimize_generated_clock_insertion_delay has default value.
## Tcl commands to replicate state of the extract_per_skew_group_source_latencies property.
# extract_per_skew_group_source_latencies has default value.
## Tcl commands to replicate state of the extract_sdc_slew_targets_for_hold property.
# extract_sdc_slew_targets_for_hold has default value.
## Tcl commands to replicate state of the extract_trace_forced_arcs property.
# extract_trace_forced_arcs has default value.
## Tcl commands to replicate state of the extract_trace_forced_arcs_insertion_delay property.
# extract_trace_forced_arcs_insertion_delay has default value.
## Tcl commands to replicate state of the extract_use_unit_delays property.
# extract_use_unit_delays has default value.
## Tcl commands to replicate state of the extract_use_zero_delays property.
# extract_use_zero_delays has default value.
## Tcl commands to replicate state of the extracted_from_clock_name property.
set_ccopt_property extracted_from_clock_name -skew_group default.clk_p_i/func_mode clk_p_i
set_ccopt_property extracted_from_clock_name -skew_group default.clk_p_i/scan_mode clk_p_i
## Tcl commands to replicate state of the extracted_from_constraint_mode_name property.
set_ccopt_property extracted_from_constraint_mode_name -skew_group default.clk_p_i/func_mode func_mode
set_ccopt_property extracted_from_constraint_mode_name -skew_group default.clk_p_i/scan_mode scan_mode
## Tcl commands to replicate state of the extracted_from_delay_corners property.
set_ccopt_property extracted_from_delay_corners -skew_group default.clk_p_i/func_mode {DC_max DC_min}
set_ccopt_property extracted_from_delay_corners -skew_group default.clk_p_i/scan_mode {DC_max DC_min}
## Tcl commands to replicate state of the extractrc_after_commit_net_attributes_and_route_estimates property.
# extractrc_after_commit_net_attributes_and_route_estimates has default value.
## Tcl commands to replicate state of the fanout_report_num_bins property.
# fanout_report_num_bins has default value.
## Tcl commands to replicate state of the fast_clock_extraction property.
# fast_clock_extraction has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_ecsm_pin_cap_cache_size property.
# fast_delay_calc_set_ecsm_pin_cap_cache_size has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_margin_for_convergence_in_delay_with_ecsm_pin_cap property.
# fast_delay_calc_set_margin_for_convergence_in_delay_with_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_margin_for_convergence_in_slew_with_ecsm_pin_cap property.
# fast_delay_calc_set_margin_for_convergence_in_slew_with_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_max_iter_for_ecsm_pin_cap property.
# fast_delay_calc_set_max_iter_for_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_aae_for_gate_model property.
# fast_delay_calc_use_aae_for_gate_model has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_for_slew property.
# fast_delay_calc_use_d2m_for_slew has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_with_ramp_input_for_delay property.
# fast_delay_calc_use_d2m_with_ramp_input_for_delay has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_with_step_input_for_delay property.
# fast_delay_calc_use_d2m_with_step_input_for_delay has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_delay_ceff property.
# fast_delay_calc_use_delay_ceff has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_ecsm_pin_cap_in_first_iteration property.
# fast_delay_calc_use_ecsm_pin_cap_in_first_iteration has default value.
## Tcl commands to replicate state of the fast_path_multiple property.
set_ccopt_property fast_path_multiple 1
## Tcl commands to replicate state of the fast_path_multiple_debug_limits property.
# fast_path_multiple_debug_limits has default value.
## Tcl commands to replicate state of the fast_pre_route_cap_extraction property.
# fast_pre_route_cap_extraction has default value.
## Tcl commands to replicate state of the fast_trial_debug_placeable_regions property.
# fast_trial_debug_placeable_regions has default value.
## Tcl commands to replicate state of the fast_trial_use_overlay property.
# fast_trial_use_overlay has default value.
## Tcl commands to replicate state of the fastest_buffer property.
# fastest_buffer has default value.
## Tcl commands to replicate state of the fastest_buffer_max_trans property.
# fastest_buffer_max_trans has default value.
## Tcl commands to replicate state of the fastest_inverter property.
# fastest_inverter has default value.
## Tcl commands to replicate state of the fastest_inverter_max_trans property.
# fastest_inverter_max_trans has default value.
## Tcl commands to replicate state of the filter_cell_lists_for_frequency_dependent_max_cap_constraints property.
# filter_cell_lists_for_frequency_dependent_max_cap_constraints has default value.
## Tcl commands to replicate state of the find_clustering_level_lunk_node_bounding_box_limit property.
# find_clustering_level_lunk_node_bounding_box_limit has default value.
## Tcl commands to replicate state of the find_clustering_level_lunk_sink_count_ratio property.
# find_clustering_level_lunk_sink_count_ratio has default value.
## Tcl commands to replicate state of the find_max_driver_cap_default_separation property.
# find_max_driver_cap_default_separation has default value.
## Tcl commands to replicate state of the find_max_driver_cap_use_zero_and_default_wire_separation property.
# find_max_driver_cap_use_zero_and_default_wire_separation has default value.
## Tcl commands to replicate state of the fix_clock_gate_enable_slacks_after_cluster property.
# fix_clock_gate_enable_slacks_after_cluster has default value.
## Tcl commands to replicate state of the fix_clock_routes_during_final_implementation property.
# fix_clock_routes_during_final_implementation has default value.
## Tcl commands to replicate state of the flexible_htree_allow_dead_branches property.
# flexible_htree_allow_dead_branches has default value.
## Tcl commands to replicate state of the flexible_htree_allow_sink_grid_center_expansion property.
# flexible_htree_allow_sink_grid_center_expansion has default value.
## Tcl commands to replicate state of the flexible_htree_allow_skewed_path_lengths property.
# flexible_htree_allow_skewed_path_lengths has default value.
## Tcl commands to replicate state of the flexible_htree_beam_width property.
# flexible_htree_beam_width has default value.
## Tcl commands to replicate state of the flexible_htree_best_effort_placement_expansion property.
# flexible_htree_best_effort_placement_expansion has default value.
## Tcl commands to replicate state of the flexible_htree_best_path_length_margin property.
# flexible_htree_best_path_length_margin has default value.
## Tcl commands to replicate state of the flexible_htree_blocked_driver_cost property.
# flexible_htree_blocked_driver_cost has default value.
## Tcl commands to replicate state of the flexible_htree_cluster_band_multiplier property.
# flexible_htree_cluster_band_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_cluster_band_row_height_multiplier property.
# flexible_htree_cluster_band_row_height_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_cluster_tolerance_factor property.
# flexible_htree_cluster_tolerance_factor has default value.
## Tcl commands to replicate state of the flexible_htree_consider_blocked_strip_nets property.
# flexible_htree_consider_blocked_strip_nets has default value.
## Tcl commands to replicate state of the flexible_htree_dead_branches_may_cross_partition_boundaries property.
# flexible_htree_dead_branches_may_cross_partition_boundaries has default value.
## Tcl commands to replicate state of the flexible_htree_default_layer_density property.
# flexible_htree_default_layer_density has default value.
## Tcl commands to replicate state of the flexible_htree_default_target_grid_step_multiplier property.
# flexible_htree_default_target_grid_step_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_dist_tolerance_factor property.
# flexible_htree_dist_tolerance_factor has default value.
## Tcl commands to replicate state of the flexible_htree_diversity_interval property.
# flexible_htree_diversity_interval has default value.
## Tcl commands to replicate state of the flexible_htree_driven_fold_back_cost property.
# flexible_htree_driven_fold_back_cost has default value.
## Tcl commands to replicate state of the flexible_htree_driver_asymmetry_cost property.
# flexible_htree_driver_asymmetry_cost has default value.
## Tcl commands to replicate state of the flexible_htree_driver_cost_in_microns property.
# flexible_htree_driver_cost_in_microns has default value.
## Tcl commands to replicate state of the flexible_htree_driver_levels_increase_cost property.
# flexible_htree_driver_levels_increase_cost has default value.
## Tcl commands to replicate state of the flexible_htree_drv_cost property.
# flexible_htree_drv_cost has default value.
## Tcl commands to replicate state of the flexible_htree_early_global_grid_sink_expansion property.
# flexible_htree_early_global_grid_sink_expansion has default value.
## Tcl commands to replicate state of the flexible_htree_enable_local_search property.
# flexible_htree_enable_local_search has default value.
## Tcl commands to replicate state of the flexible_htree_extend_route_guides_to_drivers property.
# flexible_htree_extend_route_guides_to_drivers has default value.
## Tcl commands to replicate state of the flexible_htree_filter_taps property.
# flexible_htree_filter_taps has default value.
## Tcl commands to replicate state of the flexible_htree_fold_back_cost property.
# flexible_htree_fold_back_cost has default value.
## Tcl commands to replicate state of the flexible_htree_global_search_iteration_limit_per_step property.
# flexible_htree_global_search_iteration_limit_per_step has default value.
## Tcl commands to replicate state of the flexible_htree_global_search_iterations_per_step_high property.
# flexible_htree_global_search_iterations_per_step_high has default value.
## Tcl commands to replicate state of the flexible_htree_global_search_iterations_per_step_low property.
# flexible_htree_global_search_iterations_per_step_low has default value.
## Tcl commands to replicate state of the flexible_htree_global_search_iterations_per_step_medium property.
# flexible_htree_global_search_iterations_per_step_medium has default value.
## Tcl commands to replicate state of the flexible_htree_grid_coarsening_factor property.
# flexible_htree_grid_coarsening_factor has default value.
## Tcl commands to replicate state of the flexible_htree_grid_detour_factor property.
# flexible_htree_grid_detour_factor has default value.
## Tcl commands to replicate state of the flexible_htree_grid_halo_expansion_multiplier property.
# flexible_htree_grid_halo_expansion_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_halo_violation_cost property.
# flexible_htree_halo_violation_cost has default value.
## Tcl commands to replicate state of the flexible_htree_hterm_locations property.
# flexible_htree_hterm_locations has default value.
## Tcl commands to replicate state of the flexible_htree_ideal_driver_dist_excess_cost property.
# flexible_htree_ideal_driver_dist_excess_cost has default value.
## Tcl commands to replicate state of the flexible_htree_ignore_strip_net_min_space property.
# flexible_htree_ignore_strip_net_min_space has default value.
## Tcl commands to replicate state of the flexible_htree_local_search_iterations_per_step_high property.
# flexible_htree_local_search_iterations_per_step_high has default value.
## Tcl commands to replicate state of the flexible_htree_local_search_iterations_per_step_low property.
# flexible_htree_local_search_iterations_per_step_low has default value.
## Tcl commands to replicate state of the flexible_htree_local_search_iterations_per_step_medium property.
# flexible_htree_local_search_iterations_per_step_medium has default value.
## Tcl commands to replicate state of the flexible_htree_max_route_guide_expansion property.
# flexible_htree_max_route_guide_expansion has default value.
## Tcl commands to replicate state of the flexible_htree_max_source_sink_increase property.
# flexible_htree_max_source_sink_increase has default value.
## Tcl commands to replicate state of the flexible_htree_max_synthesis_grid_points property.
# flexible_htree_max_synthesis_grid_points has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_base_length_fraction property.
# flexible_htree_merge_point_base_length_fraction has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_detour_cost property.
# flexible_htree_merge_point_detour_cost has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_driver_level_excess_cost property.
# flexible_htree_merge_point_driver_level_excess_cost has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_length_imbalance_cost property.
# flexible_htree_merge_point_length_imbalance_cost has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_length_mismatch_cost property.
# flexible_htree_merge_point_length_mismatch_cost has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_tolerance property.
# flexible_htree_merge_point_tolerance has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_turn_cost property.
# flexible_htree_merge_point_turn_cost has default value.
## Tcl commands to replicate state of the flexible_htree_merge_point_twist_cost property.
# flexible_htree_merge_point_twist_cost has default value.
## Tcl commands to replicate state of the flexible_htree_min_ideal_driver_dist_multiplier property.
# flexible_htree_min_ideal_driver_dist_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_min_run_length_increase property.
# flexible_htree_min_run_length_increase has default value.
## Tcl commands to replicate state of the flexible_htree_min_split_level_violation_cost property.
# flexible_htree_min_split_level_violation_cost has default value.
## Tcl commands to replicate state of the flexible_htree_nets property.
# flexible_htree_nets has default value.
## Tcl commands to replicate state of the flexible_htree_new_symmetric property.
# flexible_htree_new_symmetric has default value.
## Tcl commands to replicate state of the flexible_htree_no_cluster_band_min_tree_levels property.
# flexible_htree_no_cluster_band_min_tree_levels has default value.
## Tcl commands to replicate state of the flexible_htree_non_min_length_cost property.
# flexible_htree_non_min_length_cost has default value.
## Tcl commands to replicate state of the flexible_htree_num_quantized_slews property.
# flexible_htree_num_quantized_slews has default value.
## Tcl commands to replicate state of the flexible_htree_overflow_cost property.
# flexible_htree_overflow_cost has default value.
## Tcl commands to replicate state of the flexible_htree_partition_boundary_net_length_excess_cost property.
# flexible_htree_partition_boundary_net_length_excess_cost has default value.
## Tcl commands to replicate state of the flexible_htree_preferred_rectangle_center_factor property.
# flexible_htree_preferred_rectangle_center_factor has default value.
## Tcl commands to replicate state of the flexible_htree_rotate_buffers property.
# flexible_htree_rotate_buffers has default value.
## Tcl commands to replicate state of the flexible_htree_route_gcell_grid_size property.
# flexible_htree_route_gcell_grid_size has default value.
## Tcl commands to replicate state of the flexible_htree_self_intersection_cost property.
# flexible_htree_self_intersection_cost has default value.
## Tcl commands to replicate state of the flexible_htree_simple_route_guides property.
# flexible_htree_simple_route_guides has default value.
## Tcl commands to replicate state of the flexible_htree_sink_at_intersections property.
# flexible_htree_sink_at_intersections has default value.
## Tcl commands to replicate state of the flexible_htree_sink_expansion property.
# flexible_htree_sink_expansion has default value.
## Tcl commands to replicate state of the flexible_htree_sparse_merge_points property.
# flexible_htree_sparse_merge_points has default value.
## Tcl commands to replicate state of the flexible_htree_split_asymmetry_cost property.
# flexible_htree_split_asymmetry_cost has default value.
## Tcl commands to replicate state of the flexible_htree_straighten_routes property.
# flexible_htree_straighten_routes has default value.
## Tcl commands to replicate state of the flexible_htree_strip_net_width_threshold property.
# flexible_htree_strip_net_width_threshold has default value.
## Tcl commands to replicate state of the flexible_htree_symmetric_force_schedule property.
# flexible_htree_symmetric_force_schedule has default value.
## Tcl commands to replicate state of the flexible_htree_symmetric_limited_legalization property.
# flexible_htree_symmetric_limited_legalization has default value.
## Tcl commands to replicate state of the flexible_htree_trunk_cell_blocked_warning_threshold property.
# flexible_htree_trunk_cell_blocked_warning_threshold has default value.
## Tcl commands to replicate state of the flexible_htree_turn_weight property.
# flexible_htree_turn_weight has default value.
## Tcl commands to replicate state of the flexible_htree_use_early_global_grid property.
# flexible_htree_use_early_global_grid has default value.
## Tcl commands to replicate state of the flexible_htree_use_refine_place property.
# flexible_htree_use_refine_place has default value.
## Tcl commands to replicate state of the flexible_htree_verbose_balancer_initialize property.
# flexible_htree_verbose_balancer_initialize has default value.
## Tcl commands to replicate state of the flexible_htree_wire_asymmetry_cost property.
# flexible_htree_wire_asymmetry_cost has default value.
## Tcl commands to replicate state of the flexible_htree_wire_length_weight property.
# flexible_htree_wire_length_weight has default value.
## Tcl commands to replicate state of the forbid_leaf_drivers_to_move_over_cts_optimization property.
# forbid_leaf_drivers_to_move_over_cts_optimization has default value.
## Tcl commands to replicate state of the force_all_module_boundaries_dont_touch property.
# force_all_module_boundaries_dont_touch has default value.
## Tcl commands to replicate state of the force_all_virtual_delay_updates property.
# force_all_virtual_delay_updates has default value.
## Tcl commands to replicate state of the force_analysis_with_abstract_stage_delay_model property.
# force_analysis_with_abstract_stage_delay_model has default value.
## Tcl commands to replicate state of the force_analysis_with_estimated_routes property.
# force_analysis_with_estimated_routes has default value.
## Tcl commands to replicate state of the force_analysis_with_fast_delay_calc property.
# force_analysis_with_fast_delay_calc has default value.
## Tcl commands to replicate state of the force_analysis_with_next_stage_cap_estimate property.
# force_analysis_with_next_stage_cap_estimate has default value.
## Tcl commands to replicate state of the force_clock_topology_changed_after_adjustment property.
# force_clock_topology_changed_after_adjustment has default value.
## Tcl commands to replicate state of the force_clock_topology_changed_after_recalibrate property.
# force_clock_topology_changed_after_recalibrate has default value.
## Tcl commands to replicate state of the force_clock_topology_changed_before_adjustment property.
# force_clock_topology_changed_before_adjustment has default value.
## Tcl commands to replicate state of the force_clock_tree property.
# force_clock_tree has default value for all objects.
## Tcl commands to replicate state of the force_cloning_of_gates_and_logics_with_sparse_fanout property.
# force_cloning_of_gates_and_logics_with_sparse_fanout has default value.
## Tcl commands to replicate state of the force_cluster_only property.
# force_cluster_only has default value.
## Tcl commands to replicate state of the force_design_routing_status property.
# force_design_routing_status has default value.
## Tcl commands to replicate state of the force_ilm_keepflatten_status property.
set_ccopt_property force_ilm_keepflatten_status false
## Tcl commands to replicate state of the force_nanoroute_single_threaded property.
# force_nanoroute_single_threaded has default value.
## Tcl commands to replicate state of the force_update_io_latency property.
# force_update_io_latency has default value.
## Tcl commands to replicate state of the force_use_of_eagl_route_only property.
set_ccopt_property force_use_of_eagl_route_only 0
## Tcl commands to replicate state of the force_virtual_delay_update_before_skewing_adjustors property.
# force_virtual_delay_update_before_skewing_adjustors has default value.
## Tcl commands to replicate state of the frequency_dependent_max_cap_usability_check_max_cap_fanout_factor property.
# frequency_dependent_max_cap_usability_check_max_cap_fanout_factor has default value.
## Tcl commands to replicate state of the generate_nanoroute_vias property.
# generate_nanoroute_vias has default value.
## Tcl commands to replicate state of the get_downstream_net_for_sink property.
# get_downstream_net_for_sink has default value.
## Tcl commands to replicate state of the global_route_and_buffer_clock_trees property.
# global_route_and_buffer_clock_trees has default value.
## Tcl commands to replicate state of the global_route_and_buffer_clock_trees_with_trunk_rules property.
# global_route_and_buffer_clock_trees_with_trunk_rules has default value.
## Tcl commands to replicate state of the global_route_chains_create_routing_obstructions property.
# global_route_chains_create_routing_obstructions has default value.
## Tcl commands to replicate state of the global_route_chains_early_global_dump_book_shelf_files property.
# global_route_chains_early_global_dump_book_shelf_files has default value.
## Tcl commands to replicate state of the global_route_chains_high_effort property.
# global_route_chains_high_effort has default value.
## Tcl commands to replicate state of the global_route_chains_prioritize_nets_by_underdelay property.
# global_route_chains_prioritize_nets_by_underdelay has default value.
## Tcl commands to replicate state of the global_route_chains_punch_through_distance property.
# global_route_chains_punch_through_distance has default value.
## Tcl commands to replicate state of the global_route_chains_reroute_and_buffer_everything property.
# global_route_chains_reroute_and_buffer_everything has default value.
## Tcl commands to replicate state of the global_route_chains_route_buffering_location_multiplier property.
# global_route_chains_route_buffering_location_multiplier has default value.
## Tcl commands to replicate state of the ground_xcaps property.
# ground_xcaps has default value.
## Tcl commands to replicate state of the guide_terminal_edge_filter_threshold_multiple_of_m2_pitch property.
# guide_terminal_edge_filter_threshold_multiple_of_m2_pitch has default value.
## Tcl commands to replicate state of the gzip_debug property.
# gzip_debug has default value.
## Tcl commands to replicate state of the ignore_unpreserved_undriven_output_ports property.
# ignore_unpreserved_undriven_output_ports has default value.
## Tcl commands to replicate state of the igpc_clone_and_divide_overslew_threshold property.
# igpc_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the igpc_downsize_algorithm_passes property.
# igpc_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the igpc_downsize_algorithm_use_single_step property.
# igpc_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the igpc_downsize_slew_target_multiplier property.
# igpc_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the igpc_drv_buffering_number_to_keep property.
# igpc_drv_buffering_number_to_keep has default value.
## Tcl commands to replicate state of the igpc_drv_buffering_second_pass_number_to_keep property.
# igpc_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the igpc_enable property.
# igpc_enable has default value.
## Tcl commands to replicate state of the igpc_enable_clone_and_divide property.
# igpc_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the igpc_enable_down_sizing_pass property.
# igpc_enable_down_sizing_pass has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_by_rebuffering property.
# igpc_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_by_rebuffering_second_pass property.
# igpc_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_with_restructuring property.
# igpc_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the igpc_enable_drv_initial_sizing property.
# igpc_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the igpc_enable_initial_down_sizing_pass property.
# igpc_enable_initial_down_sizing_pass has default value.
## Tcl commands to replicate state of the igpc_enable_max_length_checks property.
# igpc_enable_max_length_checks has default value.
## Tcl commands to replicate state of the igpc_enable_move_down property.
# igpc_enable_move_down has default value.
## Tcl commands to replicate state of the igpc_enable_skew_fixing_by_cell_sizing property.
# igpc_enable_skew_fixing_by_cell_sizing has default value.
## Tcl commands to replicate state of the igpc_enable_skew_fixing_by_rebuffering property.
# igpc_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the igpc_max_move_multiplier property.
# igpc_max_move_multiplier has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_buffering_in_ps property.
# igpc_min_overslew_to_fix_using_buffering_in_ps has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_buffering_second_pass_in_ps property.
# igpc_min_overslew_to_fix_using_buffering_second_pass_in_ps has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_sizing_in_ps property.
# igpc_min_overslew_to_fix_using_sizing_in_ps has default value.
## Tcl commands to replicate state of the igpc_update_timing property.
# igpc_update_timing has default value.
## Tcl commands to replicate state of the igpc_use_fast_cell_sizing_algorithm property.
# igpc_use_fast_cell_sizing_algorithm has default value.
## Tcl commands to replicate state of the importance property.
# importance has default value for all objects.
## Tcl commands to replicate state of the improved_conditional_arc_cell_equivalence_check property.
# improved_conditional_arc_cell_equivalence_check has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_preserves_route_lengths property.
# improving_clock_tree_routing_preserves_route_lengths has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_preserves_subtree_skew property.
# improving_clock_tree_routing_preserves_subtree_skew has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing property.
# improving_clock_tree_routing_use_routing has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_include_driver_location property.
# improving_clock_tree_routing_use_routing_include_driver_location has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_move_leaves property.
# improving_clock_tree_routing_use_routing_move_leaves has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_skew_margin property.
# improving_clock_tree_routing_use_routing_skew_margin has default value.
## Tcl commands to replicate state of the improving_skew_before_reducing_clock_tree_power property.
# improving_skew_before_reducing_clock_tree_power has default value.
## Tcl commands to replicate state of the improving_skew_target_wire_skew property.
# improving_skew_target_wire_skew has default value.
## Tcl commands to replicate state of the inbound_cell_area_fix property.
# inbound_cell_area_fix has default value.
## Tcl commands to replicate state of the include_source_latency property.
set_ccopt_property include_source_latency -skew_group default.clk_p_i/func_mode 1
set_ccopt_property include_source_latency -skew_group default.clk_p_i/scan_mode 1
set_ccopt_property include_source_latency -skew_group icts.clk_p_i/func_mode 1
## Tcl commands to replicate state of the include_vias_when_treating_special_nets_as_routing_blockages property.
# include_vias_when_treating_special_nets_as_routing_blockages has default value.
## Tcl commands to replicate state of the init_adjust_sink_grid_for_aspect_ratio property.
# init_adjust_sink_grid_for_aspect_ratio has default value for all objects.
## Tcl commands to replicate state of the init_cannot_clone_reason property.
# init_cannot_clone_reason has default value for all objects.
## Tcl commands to replicate state of the init_cannot_fix_pre_route property.
# init_cannot_fix_pre_route has default value for all objects.
## Tcl commands to replicate state of the init_cannot_merge_reason property.
# init_cannot_merge_reason has default value for all objects.
## Tcl commands to replicate state of the init_chosen_route_type property.
# init_chosen_route_type has default value for all objects.
## Tcl commands to replicate state of the init_clock_domain_skew_group property.
# init_clock_domain_skew_group has default value for all objects.
## Tcl commands to replicate state of the init_clock_period property.
# init_clock_period has default value for all objects.
## Tcl commands to replicate state of the init_cluster_for_htree_topology property.
# init_cluster_for_htree_topology has default value for all objects.
## Tcl commands to replicate state of the init_clustering_region property.
# init_clustering_region has default value for all objects.
## Tcl commands to replicate state of the init_effort property.
# init_effort has default value for all objects.
## Tcl commands to replicate state of the init_exclude_delays_below_sinks property.
# init_exclude_delays_below_sinks has default value for all objects.
## Tcl commands to replicate state of the init_exclusion_zones property.
# init_exclusion_zones has default value for all objects.
## Tcl commands to replicate state of the init_exclusive_sinks_rank property.
# init_exclusive_sinks_rank has default value for all objects.
## Tcl commands to replicate state of the init_exp_flexible_htree_layer_demote_distance property.
# init_exp_flexible_htree_layer_demote_distance has default value for all objects.
## Tcl commands to replicate state of the init_final_cell property.
# init_final_cell has default value for all objects.
## Tcl commands to replicate state of the init_gnuplot property.
# init_gnuplot has default value for all objects.
## Tcl commands to replicate state of the init_htree_relative_inst_name property.
# init_htree_relative_inst_name has default value for all objects.
## Tcl commands to replicate state of the init_htree_sinks property.
# init_htree_sinks has default value for all objects.
## Tcl commands to replicate state of the init_hv_balance property.
# init_hv_balance has default value for all objects.
## Tcl commands to replicate state of the init_image property.
# init_image has default value for all objects.
## Tcl commands to replicate state of the init_image_directory property.
# init_image_directory has default value for all objects.
## Tcl commands to replicate state of the init_insertion_delay property.
# init_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_insertion_delay_wire property.
# init_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the init_inverting property.
# init_inverting has default value for all objects.
## Tcl commands to replicate state of the init_is_clone property.
# init_is_clone has default value for all objects.
## Tcl commands to replicate state of the init_layer_density property.
# init_layer_density has default value for all objects.
## Tcl commands to replicate state of the init_locked_originally property.
# init_locked_originally has default value for all objects.
## Tcl commands to replicate state of the init_max_driver_distance property.
# init_max_driver_distance has default value for all objects.
## Tcl commands to replicate state of the init_max_root_distance property.
# init_max_root_distance has default value for all objects.
## Tcl commands to replicate state of the init_maximum_insertion_delay property.
# init_maximum_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_maximum_stage_depth property.
# init_maximum_stage_depth has default value for all objects.
## Tcl commands to replicate state of the init_mode property.
# init_mode has default value for all objects.
## Tcl commands to replicate state of the init_net_unbufferable_flags property.
# init_net_unbufferable_flags has default value for all objects.
## Tcl commands to replicate state of the init_no_symmetry_buffers property.
# init_no_symmetry_buffers has default value for all objects.
## Tcl commands to replicate state of the init_offset_x property.
# init_offset_x has default value for all objects.
## Tcl commands to replicate state of the init_offset_y property.
# init_offset_y has default value for all objects.
## Tcl commands to replicate state of the init_original_names property.
# init_original_names has default value for all objects.
## Tcl commands to replicate state of the init_partition_boundary_inverting property.
# init_partition_boundary_inverting has default value for all objects.
## Tcl commands to replicate state of the init_partition_groups property.
# init_partition_groups has default value for all objects.
## Tcl commands to replicate state of the init_pin property.
# init_pin has default value for all objects.
## Tcl commands to replicate state of the init_power_weight property.
# init_power_weight has default value for all objects.
## Tcl commands to replicate state of the init_pre_routed property.
# init_pre_routed has default value for all objects.
## Tcl commands to replicate state of the init_preferred_min_split_level property.
# init_preferred_min_split_level has default value for all objects.
## Tcl commands to replicate state of the init_prioritize_driver_levels property.
# init_prioritize_driver_levels has default value for all objects.
## Tcl commands to replicate state of the init_problem property.
# init_problem has default value for all objects.
## Tcl commands to replicate state of the init_route_topology property.
# init_route_topology has default value for all objects.
## Tcl commands to replicate state of the init_routing_override property.
# init_routing_override has default value for all objects.
## Tcl commands to replicate state of the init_routing_top_fanout_count property.
# init_routing_top_fanout_count has default value for all objects.
## Tcl commands to replicate state of the init_single_driver_per_grid_point property.
# init_single_driver_per_grid_point has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid property.
# init_sink_grid has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_box property.
# init_sink_grid_box has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_exclusion_zones property.
# init_sink_grid_exclusion_zones has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_sink_area property.
# init_sink_grid_sink_area has default value for all objects.
## Tcl commands to replicate state of the init_sink_instance_prefix property.
# init_sink_instance_prefix has default value for all objects.
## Tcl commands to replicate state of the init_sink_pin_merge_area property.
# init_sink_pin_merge_area has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_insertion_delay property.
# init_skew_group_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_insertion_delay_wire property.
# init_skew_group_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_source_latency property.
# init_skew_group_source_latency has default value for all objects.
## Tcl commands to replicate state of the init_source_group_clock_trees property.
# init_source_group_clock_trees has default value for all objects.
## Tcl commands to replicate state of the init_stop_at_sdc_clock_roots property.
# init_stop_at_sdc_clock_roots has default value for all objects.
## Tcl commands to replicate state of the init_symmetric_bottom_level_merge_direction property.
# init_symmetric_bottom_level_merge_direction has default value for all objects.
## Tcl commands to replicate state of the init_target_centers property.
# init_target_centers has default value for all objects.
## Tcl commands to replicate state of the init_trunk_cell property.
# init_trunk_cell has default value for all objects.
## Tcl commands to replicate state of the init_user_skew_group property.
# init_user_skew_group has default value for all objects.
## Tcl commands to replicate state of the init_virtual_delay property.
# init_virtual_delay has default value for all objects.
## Tcl commands to replicate state of the initialize_cte_for_aae_mode property.
# initialize_cte_for_aae_mode has default value.
## Tcl commands to replicate state of the insert_source_group_roots_verbose_balancer_initialize property.
# insert_source_group_roots_verbose_balancer_initialize has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_clone_at_leaf property.
# insertion_delay_outlier_clone_at_leaf has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_iteration_db_prefix property.
# insertion_delay_outlier_iteration_db_prefix has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_iteration_limit property.
# insertion_delay_outlier_iteration_limit has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_min_num_skew_group_sinks property.
# insertion_delay_outlier_min_num_skew_group_sinks has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_standard_deviation_factor property.
# insertion_delay_outlier_standard_deviation_factor has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_try_cloning property.
# insertion_delay_outlier_try_cloning has default value.
## Tcl commands to replicate state of the inst_name_prefix property.
# inst_name_prefix has default value.
## Tcl commands to replicate state of the integration property.
# integration has default value.
## Tcl commands to replicate state of the invalidate_timing_graph_after_disconnect_clock_trees property.
# invalidate_timing_graph_after_disconnect_clock_trees has default value.
## Tcl commands to replicate state of the inverter_cells property.
# inverter_cells has default value for all objects.
## Tcl commands to replicate state of the io_iterations property.
# io_iterations has default value.
## Tcl commands to replicate state of the is_clone property.
# is_clone has default value for all objects.
## Tcl commands to replicate state of the keep_clock_gates_in_same_family property.
# keep_clock_gates_in_same_family has default value.
## Tcl commands to replicate state of the keep_global_routes_after_post_conditioning property.
# keep_global_routes_after_post_conditioning has default value.
## Tcl commands to replicate state of the keep_global_routes_source_sink_length_delta property.
# keep_global_routes_source_sink_length_delta has default value.
## Tcl commands to replicate state of the keep_global_routes_total_length_delta property.
# keep_global_routes_total_length_delta has default value.
## Tcl commands to replicate state of the keep_global_routes_where_lengths_differ property.
# keep_global_routes_where_lengths_differ has default value.
## Tcl commands to replicate state of the last_target_insertion_delay property.
set_ccopt_property last_target_insertion_delay -skew_group default.clk_p_i/func_mode 1.0294
set_ccopt_property last_target_insertion_delay -skew_group default.clk_p_i/scan_mode 1.0294
set_ccopt_property last_target_insertion_delay -skew_group icts.clk_p_i/func_mode 1.0294
set_ccopt_property last_target_insertion_delay -skew_group fragment.1 1.08745
## Tcl commands to replicate state of the last_target_insertion_delay_wire property.
# last_target_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the last_target_max_trans property.
set_ccopt_property last_target_max_trans -clock_tree clk_p_i -delay_corner DC_max -net_type leaf -late 0.222
set_ccopt_property last_target_max_trans -clock_tree clk_p_i -delay_corner DC_max -net_type trunk -late 0.222
set_ccopt_property last_target_max_trans -clock_tree clk_p_i -delay_corner DC_max -net_type top -late 0.222
## Tcl commands to replicate state of the last_target_skew property.
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group default.clk_p_i/func_mode -early 0.134
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group default.clk_p_i/func_mode -late 0.134
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group default.clk_p_i/func_mode -early 0.0588
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group default.clk_p_i/func_mode -late 0.0588
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group default.clk_p_i/scan_mode -early 0.134
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group default.clk_p_i/scan_mode -late 0.134
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group default.clk_p_i/scan_mode -early 0.0588
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group default.clk_p_i/scan_mode -late 0.0588
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -early 0.134
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -late 0.134
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -early 0.0588
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -late 0.0588
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group fragment.1 -early 0.0205
set_ccopt_property last_target_skew -delay_corner DC_max -skew_group fragment.1 -late 0.0205
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group fragment.1 -early 0.009
set_ccopt_property last_target_skew -delay_corner DC_min -skew_group fragment.1 -late 0.009
## Tcl commands to replicate state of the last_target_skew_wire property.
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group default.clk_p_i/func_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group default.clk_p_i/func_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group default.clk_p_i/func_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group default.clk_p_i/func_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group default.clk_p_i/scan_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group default.clk_p_i/scan_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group default.clk_p_i/scan_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group default.clk_p_i/scan_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group fragment.1 -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_max -skew_group fragment.1 -late 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group fragment.1 -early 0
set_ccopt_property last_target_skew_wire -delay_corner DC_min -skew_group fragment.1 -late 0
## Tcl commands to replicate state of the leaf_buffer_cells property.
# leaf_buffer_cells has default value for all objects.
## Tcl commands to replicate state of the leaf_inverter_cells property.
# leaf_inverter_cells has default value for all objects.
## Tcl commands to replicate state of the legalize_on_stripes_throughout_cts property.
# legalize_on_stripes_throughout_cts has default value.
## Tcl commands to replicate state of the legalized_on_clock_spine property.
# legalized_on_clock_spine has default value for all objects.
## Tcl commands to replicate state of the legalizer_allow_drc_color_checks_for_whole_die property.
# legalizer_allow_drc_color_checks_for_whole_die has default value.
## Tcl commands to replicate state of the legalizer_disable_drc_color_checks property.
# legalizer_disable_drc_color_checks has default value.
## Tcl commands to replicate state of the legalizer_placeable_area_use_psp property.
# legalizer_placeable_area_use_psp has default value.
## Tcl commands to replicate state of the liberty_min_max_path_delay_limit_absolute property.
# liberty_min_max_path_delay_limit_absolute has default value.
## Tcl commands to replicate state of the library_trimming property.
# library_trimming has default value.
## Tcl commands to replicate state of the lock_on_clock_spine property.
# lock_on_clock_spine has default value for all objects.
## Tcl commands to replicate state of the locked_originally property.
set_ccopt_property locked_originally -inst ipad_clk_p_i true
## Tcl commands to replicate state of the log_special_case_cell_selections property.
# log_special_case_cell_selections has default value.
## Tcl commands to replicate state of the logic_cells property.
# logic_cells has default value for all objects.
## Tcl commands to replicate state of the logic_movement_limit property.
# logic_movement_limit has default value.
## Tcl commands to replicate state of the long_path_removal_cutoff_id property.
set_ccopt_property long_path_removal_cutoff_id -skew_group icts.clk_p_i/func_mode 1.09577
## Tcl commands to replicate state of the long_path_removal_percentile property.
# long_path_removal_percentile has default value for all objects.
## Tcl commands to replicate state of the long_path_removal_uses_min_offset property.
# long_path_removal_uses_min_offset has default value.
## Tcl commands to replicate state of the low_power_clustering property.
# low_power_clustering has default value for all objects.
## Tcl commands to replicate state of the macro_max_delta_slack_factor property.
# macro_max_delta_slack_factor has default value.
## Tcl commands to replicate state of the macro_max_delta_slack_factor_ideal_mode property.
# macro_max_delta_slack_factor_ideal_mode has default value.
## Tcl commands to replicate state of the maintain_skew_band_occupancy_during_reducing_clock_tree_power_3 property.
# maintain_skew_band_occupancy_during_reducing_clock_tree_power_3 has default value.
## Tcl commands to replicate state of the make_dc_think_everything_needs_recomputing property.
# make_dc_think_everything_needs_recomputing has default value.
## Tcl commands to replicate state of the manage_power_management_illegalities property.
# manage_power_management_illegalities has default value.
## Tcl commands to replicate state of the mark_only_unfixable_slews_caused_by_design_constraints property.
# mark_only_unfixable_slews_caused_by_design_constraints has default value.
## Tcl commands to replicate state of the max_buffer_depth property.
# max_buffer_depth has default value for all objects.
## Tcl commands to replicate state of the max_delta_band_factor property.
# max_delta_band_factor has default value.
## Tcl commands to replicate state of the max_delta_band_factor_ideal_mode property.
# max_delta_band_factor_ideal_mode has default value.
## Tcl commands to replicate state of the max_delta_slack_factor property.
# max_delta_slack_factor has default value.
## Tcl commands to replicate state of the max_delta_slack_factor_ideal_mode property.
# max_delta_slack_factor_ideal_mode has default value.
## Tcl commands to replicate state of the max_fanout property.
# max_fanout has default value for all objects.
## Tcl commands to replicate state of the max_hierarchy_colors property.
# max_hierarchy_colors has default value.
## Tcl commands to replicate state of the max_latency_margin property.
# max_latency_margin has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress property.
# max_skew_passes_with_insufficient_progress has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress_consider_single_pass property.
# max_skew_passes_with_insufficient_progress_consider_single_pass has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress_ideal_mode property.
# max_skew_passes_with_insufficient_progress_ideal_mode has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_length property.
# max_source_to_sink_net_length has default value for all objects.
## Tcl commands to replicate state of the max_source_to_sink_net_length_error_multiple property.
# max_source_to_sink_net_length_error_multiple has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_length_warn_multiple property.
# max_source_to_sink_net_length_warn_multiple has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_resistance property.
# max_source_to_sink_net_resistance has default value.
## Tcl commands to replicate state of the maximum_insertion_delay property.
set_ccopt_property maximum_insertion_delay -inst ipad_clk_p_i -inf
## Tcl commands to replicate state of the maximum_stage_depth property.
# maximum_stage_depth has default value for all objects.
## Tcl commands to replicate state of the merge_balancing_drivers_for_power_balancing_only property.
# merge_balancing_drivers_for_power_balancing_only has default value.
## Tcl commands to replicate state of the merge_gates_considers_cell_familes property.
# merge_gates_considers_cell_familes has default value.
## Tcl commands to replicate state of the merge_ignore_sdc property.
# merge_ignore_sdc has default value for all objects.
## Tcl commands to replicate state of the merged_clock_gates_survivor_placement property.
# merged_clock_gates_survivor_placement has default value.
## Tcl commands to replicate state of the merging_use_logic_expressions property.
# merging_use_logic_expressions has default value.
## Tcl commands to replicate state of the min_delta_band_factor property.
# min_delta_band_factor has default value.
## Tcl commands to replicate state of the min_delta_band_factor_ideal_mode property.
# min_delta_band_factor_ideal_mode has default value.
## Tcl commands to replicate state of the min_segment_length_for_shielding property.
# min_segment_length_for_shielding has default value.
## Tcl commands to replicate state of the min_trunk_net_bounding_box_hp property.
# min_trunk_net_bounding_box_hp has default value.
## Tcl commands to replicate state of the mini_not_full_band_size_factor property.
set_ccopt_property mini_not_full_band_size_factor 100
## Tcl commands to replicate state of the mixed_fanout_net_type property.
# mixed_fanout_net_type has default value.
## Tcl commands to replicate state of the move_cells_below_node_before_adding_more_buffers property.
# move_cells_below_node_before_adding_more_buffers has default value.
## Tcl commands to replicate state of the move_clock_gates_band_size property.
# move_clock_gates_band_size has default value.
## Tcl commands to replicate state of the move_clock_nodes_for_slack property.
# move_clock_nodes_for_slack has default value for all objects.
## Tcl commands to replicate state of the move_datapath_while_clock_net_routing property.
# move_datapath_while_clock_net_routing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_do_sizing property.
# move_gates_to_siblings_do_sizing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_in_bottom_up_balancing property.
# move_gates_to_siblings_in_bottom_up_balancing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_in_detailed_balancing property.
# move_gates_to_siblings_in_detailed_balancing has default value.
## Tcl commands to replicate state of the move_global_route_buffers property.
# move_global_route_buffers has default value.
## Tcl commands to replicate state of the move_logic property.
# move_logic has default value.
## Tcl commands to replicate state of the move_middle_cell_first_when_adding_wire_delay property.
# move_middle_cell_first_when_adding_wire_delay has default value.
## Tcl commands to replicate state of the move_power_management_cells property.
# move_power_management_cells has default value.
## Tcl commands to replicate state of the movement_limit property.
# movement_limit has default value for all objects.
## Tcl commands to replicate state of the movement_reports_show_top_n_movements property.
# movement_reports_show_top_n_movements has default value.
## Tcl commands to replicate state of the moving_gates_to_balance_delay_uses_net_lengths_directly property.
# moving_gates_to_balance_delay_uses_net_lengths_directly has default value.
## Tcl commands to replicate state of the moving_gates_to_improve_subtree_skew_use_route_opt property.
# moving_gates_to_improve_subtree_skew_use_route_opt has default value.
## Tcl commands to replicate state of the nanoroute_tcl_function property.
# nanoroute_tcl_function has default value.
## Tcl commands to replicate state of the neg_unate_arcs_count_half_for_stage_depth_counting property.
# neg_unate_arcs_count_half_for_stage_depth_counting has default value.
## Tcl commands to replicate state of the neg_unate_arcs_count_half_towards_maximum_stage_depth property.
# neg_unate_arcs_count_half_towards_maximum_stage_depth has default value.
## Tcl commands to replicate state of the net_name_prefix property.
# net_name_prefix has default value.
## Tcl commands to replicate state of the net_unbufferable_flags property.
set_ccopt_property net_unbufferable_flags -pin clk_p_i 65540
set_ccopt_property net_unbufferable_flags -pin ipad_clk_p_i/I 65540
## Tcl commands to replicate state of the net_violation_report_show_top_n_violations property.
# net_violation_report_show_top_n_violations has default value.
## Tcl commands to replicate state of the netlist_add_hterm_batch_size property.
# netlist_add_hterm_batch_size has default value.
## Tcl commands to replicate state of the netlist_cache_cellinst_touches_preroute property.
# netlist_cache_cellinst_touches_preroute has default value.
## Tcl commands to replicate state of the netlist_consider_assigns_in_cte_constraints property.
# netlist_consider_assigns_in_cte_constraints has default value.
## Tcl commands to replicate state of the netlist_replace_cell_physical_term_invalidate_route property.
# netlist_replace_cell_physical_term_invalidate_route has default value.
## Tcl commands to replicate state of the next_stage_cap_estimate_pin_cap_factor property.
# next_stage_cap_estimate_pin_cap_factor has default value.
## Tcl commands to replicate state of the non_default_routing_rule_propagation_behaviour property.
# non_default_routing_rule_propagation_behaviour has default value.
## Tcl commands to replicate state of the only_use_aon_cells_if_in_cpf property.
# only_use_aon_cells_if_in_cpf has default value.
## Tcl commands to replicate state of the opt_enable_cloning property.
# opt_enable_cloning has default value.
## Tcl commands to replicate state of the opt_ignore property.
# opt_ignore has default value for all objects.
## Tcl commands to replicate state of the optimize_leaf_net_placement property.
# optimize_leaf_net_placement has default value.
## Tcl commands to replicate state of the original_names property.
# original_names has default value for all objects.
## Tcl commands to replicate state of the override_minimum_max_trans_target property.
# override_minimum_max_trans_target has default value.
## Tcl commands to replicate state of the override_minimum_skew_target property.
# override_minimum_skew_target has default value.
## Tcl commands to replicate state of the override_minimum_stage_delay property.
# override_minimum_stage_delay has default value.
## Tcl commands to replicate state of the override_modify_clock_latency property.
# override_modify_clock_latency has default value.
## Tcl commands to replicate state of the override_vias property.
# override_vias has default value.
## Tcl commands to replicate state of the override_zero_placeable_area property.
# override_zero_placeable_area has default value.
## Tcl commands to replicate state of the pathoptimization_task_throttle_denominator property.
# pathoptimization_task_throttle_denominator has default value.
## Tcl commands to replicate state of the per_stage_total_delay_limit property.
# per_stage_total_delay_limit has default value.
## Tcl commands to replicate state of the per_stage_total_delay_limit_halved_for_inverting_stages property.
# per_stage_total_delay_limit_halved_for_inverting_stages has default value.
## Tcl commands to replicate state of the per_stage_wire_delay_limit property.
# per_stage_wire_delay_limit has default value.
## Tcl commands to replicate state of the per_stage_wire_delay_limit_halved_for_inverting_stages property.
# per_stage_wire_delay_limit_halved_for_inverting_stages has default value.
## Tcl commands to replicate state of the pin_allow_buffering property.
# pin_allow_buffering has default value for all objects.
## Tcl commands to replicate state of the pin_route_type property.
# pin_route_type has default value for all objects.
## Tcl commands to replicate state of the pin_target_max_trans property.
# pin_target_max_trans has default value for all objects.
## Tcl commands to replicate state of the pin_use_inverters property.
# pin_use_inverters has default value for all objects.
## Tcl commands to replicate state of the place_honor_fence_fix property.
# place_honor_fence_fix has default value.
## Tcl commands to replicate state of the place_read_only property.
# place_read_only has default value.
## Tcl commands to replicate state of the place_use_far_eye_optimization property.
# place_use_far_eye_optimization has default value.
## Tcl commands to replicate state of the place_use_partial_cleanup property.
# place_use_partial_cleanup has default value.
## Tcl commands to replicate state of the place_use_reset_site_arr property.
# place_use_reset_site_arr has default value.
## Tcl commands to replicate state of the place_use_tcl_mode_setting property.
# place_use_tcl_mode_setting has default value.
## Tcl commands to replicate state of the placeable_region_is_overlap_ok property.
# placeable_region_is_overlap_ok has default value.
## Tcl commands to replicate state of the port_preservation_store property.
set_ccopt_property port_preservation_store {}
## Tcl commands to replicate state of the port_preservation_store_allow_location_on_any_port property.
# port_preservation_store_allow_location_on_any_port has default value.
## Tcl commands to replicate state of the post_conditioning property.
# post_conditioning has default value.
## Tcl commands to replicate state of the post_conditioning_auto_set_longest_path_removal_thresholds property.
# post_conditioning_auto_set_longest_path_removal_thresholds has default value.
## Tcl commands to replicate state of the post_conditioning_auto_set_longest_path_removal_thresholds_factor property.
# post_conditioning_auto_set_longest_path_removal_thresholds_factor has default value.
## Tcl commands to replicate state of the post_conditioning_clone_and_divide_overslew_threshold property.
# post_conditioning_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the post_conditioning_debug_second_pass property.
# post_conditioning_debug_second_pass has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_algorithm_passes property.
# post_conditioning_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_algorithm_use_single_step property.
# post_conditioning_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_slew_target_multiplier property.
# post_conditioning_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the post_conditioning_enable_average_id_reduction property.
# post_conditioning_enable_average_id_reduction has default value.
## Tcl commands to replicate state of the post_conditioning_enable_clone_and_divide property.
# post_conditioning_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the post_conditioning_enable_delete property.
# post_conditioning_enable_delete has default value.
## Tcl commands to replicate state of the post_conditioning_enable_downsizing_pass property.
# post_conditioning_enable_downsizing_pass has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing property.
# post_conditioning_enable_drv_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing_by_rebuffering property.
# post_conditioning_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing_with_restructuring property.
# post_conditioning_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_initial_sizing property.
# post_conditioning_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_initial_downsizing_pass property.
# post_conditioning_enable_initial_downsizing_pass has default value.
## Tcl commands to replicate state of the post_conditioning_enable_initial_fixing_long_paths property.
# post_conditioning_enable_initial_fixing_long_paths has default value.
## Tcl commands to replicate state of the post_conditioning_enable_max_length_checks property.
# post_conditioning_enable_max_length_checks has default value.
## Tcl commands to replicate state of the post_conditioning_enable_move_down property.
# post_conditioning_enable_move_down has default value.
## Tcl commands to replicate state of the post_conditioning_enable_routing_eco property.
# post_conditioning_enable_routing_eco has default value.
## Tcl commands to replicate state of the post_conditioning_enable_skew_fixing property.
# post_conditioning_enable_skew_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_skew_fixing_by_rebuffering property.
# post_conditioning_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the post_conditioning_enable_timing_update property.
# post_conditioning_enable_timing_update has default value.
## Tcl commands to replicate state of the post_conditioning_initial_cte_update property.
# post_conditioning_initial_cte_update has default value.
## Tcl commands to replicate state of the post_conditioning_keep_route_buffering_best_solution property.
# post_conditioning_keep_route_buffering_best_solution has default value.
## Tcl commands to replicate state of the post_conditioning_max_cell_move property.
# post_conditioning_max_cell_move has default value.
## Tcl commands to replicate state of the post_conditioning_remove_longest_paths property.
# post_conditioning_remove_longest_paths has default value.
## Tcl commands to replicate state of the post_conditioning_remove_longest_paths_after_drv_fixing property.
# post_conditioning_remove_longest_paths_after_drv_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_reroute_clock_tree property.
# post_conditioning_reroute_clock_tree has default value.
## Tcl commands to replicate state of the post_conditioning_route_select_entire_clock_tree property.
# post_conditioning_route_select_entire_clock_tree has default value.
## Tcl commands to replicate state of the post_conditioning_save_datapath_trialroutes property.
# post_conditioning_save_datapath_trialroutes has default value.
## Tcl commands to replicate state of the post_conditioning_slew_fix_sizing_preserve_skew property.
# post_conditioning_slew_fix_sizing_preserve_skew has default value.
## Tcl commands to replicate state of the post_conditioning_speed_up_cell_sizing property.
# post_conditioning_speed_up_cell_sizing has default value.
## Tcl commands to replicate state of the post_conditioning_trial_route_when_nanoroute_disabled property.
# post_conditioning_trial_route_when_nanoroute_disabled has default value.
## Tcl commands to replicate state of the post_conditioning_uses_inst_based_legalization property.
# post_conditioning_uses_inst_based_legalization has default value.
## Tcl commands to replicate state of the post_conditioning_verify_legal property.
# post_conditioning_verify_legal has default value.
## Tcl commands to replicate state of the post_cts_callback property.
# post_cts_callback has default value.
## Tcl commands to replicate state of the pre_routed property.
# pre_routed has default value for all objects.
## Tcl commands to replicate state of the prefer_trunk_routing_for_rams property.
# prefer_trunk_routing_for_rams has default value.
## Tcl commands to replicate state of the preferred_extra_space property.
set_ccopt_property preferred_extra_space -net_type leaf 1
set_ccopt_property preferred_extra_space -net_type trunk 1
## Tcl commands to replicate state of the preserve_enable_latch_clock_inverters property.
# preserve_enable_latch_clock_inverters has default value.
## Tcl commands to replicate state of the prim_dijkstra_factor property.
# prim_dijkstra_factor has default value for all objects.
## Tcl commands to replicate state of the prim_dijkstra_factor_for_clustering property.
# prim_dijkstra_factor_for_clustering has default value for all objects.
## Tcl commands to replicate state of the primary_reporting_skew_group property.
# primary_reporting_skew_group has default value.
## Tcl commands to replicate state of the pro_always_allow_buffer_individual_terminals property.
# pro_always_allow_buffer_individual_terminals has default value.
## Tcl commands to replicate state of the pro_auto_bypass_place_and_route property.
# pro_auto_bypass_place_and_route has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds property.
# pro_auto_set_longest_path_removal_thresholds has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_downsizing property.
# pro_auto_set_longest_path_removal_thresholds_downsizing has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_factor property.
# pro_auto_set_longest_path_removal_thresholds_factor has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_factor_downsizing property.
# pro_auto_set_longest_path_removal_thresholds_factor_downsizing has default value.
## Tcl commands to replicate state of the pro_buffer_move_candidate_location_count property.
# pro_buffer_move_candidate_location_count has default value.
## Tcl commands to replicate state of the pro_buffering_full_search_minimum_fraction_overslew_to_fix property.
# pro_buffering_full_search_minimum_fraction_overslew_to_fix has default value.
## Tcl commands to replicate state of the pro_buffering_minimum_fraction_overslew_to_fix property.
# pro_buffering_minimum_fraction_overslew_to_fix has default value.
## Tcl commands to replicate state of the pro_bypass_commit_rc property.
# pro_bypass_commit_rc has default value.
## Tcl commands to replicate state of the pro_can_move_datapath_insts property.
# pro_can_move_datapath_insts has default value.
## Tcl commands to replicate state of the pro_check_are_net_wires_ok property.
# pro_check_are_net_wires_ok has default value.
## Tcl commands to replicate state of the pro_check_net_rcdb_nodes_have_valid_locations property.
# pro_check_net_rcdb_nodes_have_valid_locations has default value.
## Tcl commands to replicate state of the pro_check_parents_for_slew_changes property.
# pro_check_parents_for_slew_changes has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_can_clone_clock_gates property.
# pro_clone_and_divide_can_clone_clock_gates has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_max_move_for_downsize_in_microns property.
# pro_clone_and_divide_max_move_for_downsize_in_microns has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_max_move_in_microns property.
# pro_clone_and_divide_max_move_in_microns has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_overslew_threshold property.
# pro_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the pro_commit_routing_rect_edges property.
# pro_commit_routing_rect_edges has default value.
## Tcl commands to replicate state of the pro_cte_identify_clock_tree_at_start property.
# pro_cte_identify_clock_tree_at_start has default value.
## Tcl commands to replicate state of the pro_disable_power_net_select_fix property.
# pro_disable_power_net_select_fix has default value.
## Tcl commands to replicate state of the pro_downsize_algorithm_passes property.
# pro_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the pro_downsize_algorithm_use_single_step property.
# pro_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the pro_downsize_id_threshold property.
# pro_downsize_id_threshold has default value.
## Tcl commands to replicate state of the pro_downsize_skip_close_to_target property.
# pro_downsize_skip_close_to_target has default value.
## Tcl commands to replicate state of the pro_downsize_slew_target_multiplier property.
# pro_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_drv_buffering_downsize_root property.
# pro_drv_buffering_downsize_root has default value.
## Tcl commands to replicate state of the pro_drv_buffering_second_pass_number_to_keep property.
# pro_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the pro_enable_alt_flow property.
# pro_enable_alt_flow has default value.
## Tcl commands to replicate state of the pro_enable_clone_and_divide property.
# pro_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the pro_enable_constraint_analysis_during_skew_sizing property.
# pro_enable_constraint_analysis_during_skew_sizing has default value.
## Tcl commands to replicate state of the pro_enable_delete property.
# pro_enable_delete has default value.
## Tcl commands to replicate state of the pro_enable_downsizing_pass property.
# pro_enable_downsizing_pass has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_by_rebuffering property.
# pro_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_by_rebuffering_second_pass property.
# pro_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_with_restructuring property.
# pro_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the pro_enable_drv_initial_sizing property.
# pro_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the pro_enable_initial_downsizing_pass property.
# pro_enable_initial_downsizing_pass has default value.
## Tcl commands to replicate state of the pro_enable_internals_timing_update property.
# pro_enable_internals_timing_update has default value.
## Tcl commands to replicate state of the pro_enable_max_fanout_fixing property.
# pro_enable_max_fanout_fixing has default value.
## Tcl commands to replicate state of the pro_enable_max_length_checks property.
# pro_enable_max_length_checks has default value.
## Tcl commands to replicate state of the pro_enable_move_down property.
# pro_enable_move_down has default value.
## Tcl commands to replicate state of the pro_enable_post_commit_delay_update property.
set_ccopt_property pro_enable_post_commit_delay_update 1
## Tcl commands to replicate state of the pro_enable_quick_buffer property.
# pro_enable_quick_buffer has default value.
## Tcl commands to replicate state of the pro_enable_recompute_for_slack property.
# pro_enable_recompute_for_slack has default value.
## Tcl commands to replicate state of the pro_enable_route_buffering_on_bus_nets property.
# pro_enable_route_buffering_on_bus_nets has default value.
## Tcl commands to replicate state of the pro_force_allow_datapath_overlap property.
# pro_force_allow_datapath_overlap has default value.
## Tcl commands to replicate state of the pro_id_reduction_lower_threshold property.
# pro_id_reduction_lower_threshold has default value.
## Tcl commands to replicate state of the pro_id_reduction_top_down property.
# pro_id_reduction_top_down has default value.
## Tcl commands to replicate state of the pro_id_reduction_upper_threshold property.
# pro_id_reduction_upper_threshold has default value.
## Tcl commands to replicate state of the pro_infer_routing_info property.
# pro_infer_routing_info has default value.
## Tcl commands to replicate state of the pro_insert_buffer_stitching property.
# pro_insert_buffer_stitching has default value.
## Tcl commands to replicate state of the pro_insert_buffer_stitching_preserve_cut_segment_attributes property.
# pro_insert_buffer_stitching_preserve_cut_segment_attributes has default value.
## Tcl commands to replicate state of the pro_internals_timing_update_everything property.
# pro_internals_timing_update_everything has default value.
## Tcl commands to replicate state of the pro_invalidate_timing_at_start property.
# pro_invalidate_timing_at_start has default value.
## Tcl commands to replicate state of the pro_invalidate_timing_when_resizing property.
# pro_invalidate_timing_when_resizing has default value.
## Tcl commands to replicate state of the pro_lost_resistance_threshold_multiplier property.
# pro_lost_resistance_threshold_multiplier has default value.
## Tcl commands to replicate state of the pro_mark_placed_insts property.
# pro_mark_placed_insts has default value.
## Tcl commands to replicate state of the pro_max_cell_move property.
# pro_max_cell_move has default value.
## Tcl commands to replicate state of the pro_max_nodes_in_slew_diagnostics_report property.
# pro_max_nodes_in_slew_diagnostics_report has default value.
## Tcl commands to replicate state of the pro_merge_route_and_rc_nodes property.
# pro_merge_route_and_rc_nodes has default value.
## Tcl commands to replicate state of the pro_min_clock_tree_routed_fraction property.
# pro_min_clock_tree_routed_fraction has default value.
## Tcl commands to replicate state of the pro_minimum_overslew_to_fix_ps property.
# pro_minimum_overslew_to_fix_ps has default value.
## Tcl commands to replicate state of the pro_move_down_permitted_bounding_box_reduction property.
# pro_move_down_permitted_bounding_box_reduction has default value.
## Tcl commands to replicate state of the pro_move_gate_slew_target_multiplier property.
# pro_move_gate_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_null_op_timing_change_margin property.
# pro_null_op_timing_change_margin has default value.
## Tcl commands to replicate state of the pro_optimization_slew_target_multiplier property.
# pro_optimization_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_overlap_dont_care_threshold property.
# pro_overlap_dont_care_threshold has default value.
## Tcl commands to replicate state of the pro_overlap_multiplier property.
# pro_overlap_multiplier has default value.
## Tcl commands to replicate state of the pro_prim_dijkstra_value_to_adjust_to property.
# pro_prim_dijkstra_value_to_adjust_to has default value.
## Tcl commands to replicate state of the pro_rcdb_node_mapping_strategy property.
# pro_rcdb_node_mapping_strategy has default value.
## Tcl commands to replicate state of the pro_recompute_icts_targets property.
# pro_recompute_icts_targets has default value.
## Tcl commands to replicate state of the pro_recompute_implementation_windows property.
# pro_recompute_implementation_windows has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths property.
# pro_remove_longest_paths has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths_after_drv_fixing property.
# pro_remove_longest_paths_after_drv_fixing has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths_downsizing property.
# pro_remove_longest_paths_downsizing has default value.
## Tcl commands to replicate state of the pro_renumber_vertices_for_route_traversal property.
# pro_renumber_vertices_for_route_traversal has default value.
## Tcl commands to replicate state of the pro_report_routing_correlation property.
# pro_report_routing_correlation has default value.
## Tcl commands to replicate state of the pro_report_timing_at_start property.
# pro_report_timing_at_start has default value.
## Tcl commands to replicate state of the pro_required_slew_outlier_factor property.
# pro_required_slew_outlier_factor has default value.
## Tcl commands to replicate state of the pro_reset_all_bufferability property.
# pro_reset_all_bufferability has default value.
## Tcl commands to replicate state of the pro_respect_cell_density_and_adjacent_row_legal property.
# pro_respect_cell_density_and_adjacent_row_legal has default value.
## Tcl commands to replicate state of the pro_route_buffering_prune_number_to_keep property.
# pro_route_buffering_prune_number_to_keep has default value.
## Tcl commands to replicate state of the pro_sanitize_commit_route property.
# pro_sanitize_commit_route has default value.
## Tcl commands to replicate state of the pro_sanitize_min_max_delays property.
# pro_sanitize_min_max_delays has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe property.
# pro_semi_skew_safe has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe_permitted_id_fraction_increase property.
# pro_semi_skew_safe_permitted_id_fraction_increase has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe_permitted_id_increase property.
# pro_semi_skew_safe_permitted_id_increase has default value.
## Tcl commands to replicate state of the pro_skew_aware_drv_buffering property.
# pro_skew_aware_drv_buffering has default value.
## Tcl commands to replicate state of the pro_skew_fix_buffer_overdelay property.
# pro_skew_fix_buffer_overdelay has default value.
## Tcl commands to replicate state of the pro_skew_fix_buffer_underdelay property.
# pro_skew_fix_buffer_underdelay has default value.
## Tcl commands to replicate state of the pro_skew_fix_longest property.
# pro_skew_fix_longest has default value.
## Tcl commands to replicate state of the pro_skew_fix_max_buffer_attempts_per_net property.
# pro_skew_fix_max_buffer_attempts_per_net has default value.
## Tcl commands to replicate state of the pro_skew_fix_max_outer_loop_iterations property.
# pro_skew_fix_max_outer_loop_iterations has default value.
## Tcl commands to replicate state of the pro_skew_fix_outer_loop_include_sizing property.
# pro_skew_fix_outer_loop_include_sizing has default value.
## Tcl commands to replicate state of the pro_skew_fix_relax_overdelay_in_final_pass property.
# pro_skew_fix_relax_overdelay_in_final_pass has default value.
## Tcl commands to replicate state of the pro_skew_fix_shortest property.
# pro_skew_fix_shortest has default value.
## Tcl commands to replicate state of the pro_skew_fix_size_driver_when_buffering_sinks property.
# pro_skew_fix_size_driver_when_buffering_sinks has default value.
## Tcl commands to replicate state of the pro_skew_fix_use_fast_buffer property.
# pro_skew_fix_use_fast_buffer has default value.
## Tcl commands to replicate state of the pro_skew_fixing_slew_target_multiplier property.
# pro_skew_fixing_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_skew_safe_drv_buffering property.
# pro_skew_safe_drv_buffering has default value.
## Tcl commands to replicate state of the pro_slack_fix_band_size property.
# pro_slack_fix_band_size has default value.
## Tcl commands to replicate state of the pro_slack_fix_max_adjustment_iterations property.
# pro_slack_fix_max_adjustment_iterations has default value.
## Tcl commands to replicate state of the pro_slack_fix_max_slack_to_fix property.
# pro_slack_fix_max_slack_to_fix has default value.
## Tcl commands to replicate state of the pro_slew_change_warning_threshold_ps property.
# pro_slew_change_warning_threshold_ps has default value.
## Tcl commands to replicate state of the pro_slew_fix_sizing_preserve_skew property.
# pro_slew_fix_sizing_preserve_skew has default value.
## Tcl commands to replicate state of the pro_slew_fix_use_new_version property.
# pro_slew_fix_use_new_version has default value.
## Tcl commands to replicate state of the pro_speed_up_cell_sizing property.
# pro_speed_up_cell_sizing has default value.
## Tcl commands to replicate state of the pro_standalone_update_timing_graph_at_start property.
# pro_standalone_update_timing_graph_at_start has default value.
## Tcl commands to replicate state of the pro_update_timing_graph_at_start property.
# pro_update_timing_graph_at_start has default value.
## Tcl commands to replicate state of the pro_use_inst_based_legalization property.
# pro_use_inst_based_legalization has default value.
## Tcl commands to replicate state of the pro_use_pin_metal_locations property.
# pro_use_pin_metal_locations has default value.
## Tcl commands to replicate state of the pro_use_routed_status_for_added_routes property.
# pro_use_routed_status_for_added_routes has default value.
## Tcl commands to replicate state of the pro_verbose_initialization property.
# pro_verbose_initialization has default value.
## Tcl commands to replicate state of the pro_verify_legal property.
# pro_verify_legal has default value.
## Tcl commands to replicate state of the propagate_slews property.
# propagate_slews has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_bbox_limit_multiplier property.
# quadrant_clustering_evaluator_bbox_limit_multiplier has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_cap_limit_multiplier property.
# quadrant_clustering_evaluator_cap_limit_multiplier has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_fuse_quadrants property.
# quadrant_clustering_evaluator_fuse_quadrants has default value.
## Tcl commands to replicate state of the r2r_iterations property.
set_ccopt_property r2r_iterations 1
## Tcl commands to replicate state of the ratchet_balancer_max_driver_constraint property.
# ratchet_balancer_max_driver_constraint has default value.
## Tcl commands to replicate state of the ratchet_balancer_max_iterations property.
# ratchet_balancer_max_iterations has default value.
## Tcl commands to replicate state of the rctp1_consider_skew property.
# rctp1_consider_skew has default value.
## Tcl commands to replicate state of the rctp3_preserve_skew property.
# rctp3_preserve_skew has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_max_nets_to_consider property.
# rebuffering_skew_fixer_max_nets_to_consider has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_skip_already_improved_nets property.
# rebuffering_skew_fixer_skip_already_improved_nets has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_speed_of_light_multiplier property.
# rebuffering_skew_fixer_speed_of_light_multiplier has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_unit_delay_multiplier_increment property.
# rebuffering_skew_fixer_unit_delay_multiplier_increment has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_unit_delay_multiplier_max property.
# rebuffering_skew_fixer_unit_delay_multiplier_max has default value.
## Tcl commands to replicate state of the recluster_ignore_pins property.
# recluster_ignore_pins has default value.
## Tcl commands to replicate state of the recluster_to_reduce_power property.
# recluster_to_reduce_power has default value for all objects.
## Tcl commands to replicate state of the recommit_net_attributes_and_routes_during_resynthesis property.
# recommit_net_attributes_and_routes_during_resynthesis has default value.
## Tcl commands to replicate state of the recompute_slew_target_overrides_after_reduce_clock_tree_power_1 property.
# recompute_slew_target_overrides_after_reduce_clock_tree_power_1 has default value.
## Tcl commands to replicate state of the recycle_unused_ports property.
# recycle_unused_ports has default value.
## Tcl commands to replicate state of the reducing_clock_tree_power_1_fast_mode property.
# reducing_clock_tree_power_1_fast_mode has default value.
## Tcl commands to replicate state of the refine_clock_placement_during_final_implementation property.
# refine_clock_placement_during_final_implementation has default value.
## Tcl commands to replicate state of the refine_clock_placement_single_pass property.
# refine_clock_placement_single_pass has default value.
## Tcl commands to replicate state of the refine_place_preserve_affected_routing property.
# refine_place_preserve_affected_routing has default value.
## Tcl commands to replicate state of the remove_bufferlike_clock_logic property.
# remove_bufferlike_clock_logic has default value for all objects.
## Tcl commands to replicate state of the rename_clock_tree_nets property.
# rename_clock_tree_nets has default value.
## Tcl commands to replicate state of the report_detailed_legalization property.
# report_detailed_legalization has default value.
## Tcl commands to replicate state of the report_top_notable_deviations_of_routed_length property.
# report_top_notable_deviations_of_routed_length has default value.
## Tcl commands to replicate state of the report_top_wire_delay_differences property.
# report_top_wire_delay_differences has default value.
## Tcl commands to replicate state of the report_total_virtual_delay_in_clock_dag_stats property.
# report_total_virtual_delay_in_clock_dag_stats has default value.
## Tcl commands to replicate state of the report_under_slew_in_clock_dag_stats property.
# report_under_slew_in_clock_dag_stats has default value.
## Tcl commands to replicate state of the report_unplaced_clock_fraction property.
# report_unplaced_clock_fraction has default value.
## Tcl commands to replicate state of the report_unplaced_noclock_fraction property.
# report_unplaced_noclock_fraction has default value.
## Tcl commands to replicate state of the report_worst_chain_after_clustering property.
# report_worst_chain_after_clustering has default value.
## Tcl commands to replicate state of the report_worst_chain_after_implementation property.
# report_worst_chain_after_implementation has default value.
## Tcl commands to replicate state of the report_worst_chain_after_skewing_adjustors property.
# report_worst_chain_after_skewing_adjustors has default value.
## Tcl commands to replicate state of the report_worst_chain_before_clustering property.
# report_worst_chain_before_clustering has default value.
## Tcl commands to replicate state of the report_worst_chain_before_implementation property.
# report_worst_chain_before_implementation has default value.
## Tcl commands to replicate state of the report_worst_chain_before_skewing_adjustors property.
# report_worst_chain_before_skewing_adjustors has default value.
## Tcl commands to replicate state of the reroute_preroute_during_final_implementation property.
# reroute_preroute_during_final_implementation has default value.
## Tcl commands to replicate state of the reset_clock_tree_latencies_even_if_update_io_latency_ran property.
# reset_clock_tree_latencies_even_if_update_io_latency_ran has default value.
## Tcl commands to replicate state of the reset_clock_tree_latencies_use_all_clocks property.
# reset_clock_tree_latencies_use_all_clocks has default value.
## Tcl commands to replicate state of the reset_cppr_info_before_latch_sta_update property.
# reset_cppr_info_before_latch_sta_update has default value.
## Tcl commands to replicate state of the reset_cppr_info_before_slack_update property.
# reset_cppr_info_before_slack_update has default value.
## Tcl commands to replicate state of the reset_extraction_during_update_timing_graph property.
# reset_extraction_during_update_timing_graph has default value.
## Tcl commands to replicate state of the reset_stage_delay_counters_when_write_clock_dag_timing property.
# reset_stage_delay_counters_when_write_clock_dag_timing has default value.
## Tcl commands to replicate state of the resistance_margin_absolute property.
# resistance_margin_absolute has default value.
## Tcl commands to replicate state of the resistance_margin_percentage property.
# resistance_margin_percentage has default value.
## Tcl commands to replicate state of the resize_gate_requires_a_legal_location property.
# resize_gate_requires_a_legal_location has default value.
## Tcl commands to replicate state of the respect_frequency_dependent_library_constraints property.
# respect_frequency_dependent_library_constraints has default value.
## Tcl commands to replicate state of the respect_library_dont_touch property.
# respect_library_dont_touch has default value.
## Tcl commands to replicate state of the restore_ccopt_config_fast_parse property.
# restore_ccopt_config_fast_parse has default value.
## Tcl commands to replicate state of the restrict_clock_gate_sizing_in_implementation property.
# restrict_clock_gate_sizing_in_implementation has default value.
## Tcl commands to replicate state of the restrict_clock_gate_sizing_in_implementation_threshold property.
# restrict_clock_gate_sizing_in_implementation_threshold has default value.
## Tcl commands to replicate state of the restrict_hold_window_consideration_to_primary_delay_corner property.
# restrict_hold_window_consideration_to_primary_delay_corner has default value.
## Tcl commands to replicate state of the restrict_to_floorplan_core_box property.
# restrict_to_floorplan_core_box has default value.
## Tcl commands to replicate state of the rmax_rmin_scaling_factor property.
# rmax_rmin_scaling_factor has default value.
## Tcl commands to replicate state of the rmax_rminn_num_fanout property.
# rmax_rminn_num_fanout has default value.
## Tcl commands to replicate state of the route_balancing_buffers_with_default_rule property.
# route_balancing_buffers_with_default_rule has default value.
## Tcl commands to replicate state of the route_buffering_choose_best_location_for_preserved_ports property.
# route_buffering_choose_best_location_for_preserved_ports has default value.
## Tcl commands to replicate state of the route_buffering_enable_full_search property.
# route_buffering_enable_full_search has default value.
## Tcl commands to replicate state of the route_buffering_evaluate_null_locations property.
# route_buffering_evaluate_null_locations has default value.
## Tcl commands to replicate state of the route_buffering_minimize_updates property.
# route_buffering_minimize_updates has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_double_driver_accept_reduced property.
# route_buffering_quick_buffer_double_driver_accept_reduced has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_enable_double_driver property.
# route_buffering_quick_buffer_enable_double_driver has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_enable_single_driver property.
# route_buffering_quick_buffer_enable_single_driver has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_single_driver_accept_reduced property.
# route_buffering_quick_buffer_single_driver_accept_reduced has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_single_driver_can_use_inverters property.
# route_buffering_quick_buffer_single_driver_can_use_inverters has default value.
## Tcl commands to replicate state of the route_clock_tree_nets_in_length_order property.
# route_clock_tree_nets_in_length_order has default value.
## Tcl commands to replicate state of the route_clocks_during_final_implementation_save_db property.
# route_clocks_during_final_implementation_save_db has default value.
## Tcl commands to replicate state of the route_data_nets_after_clock_net_routing property.
# route_data_nets_after_clock_net_routing has default value.
## Tcl commands to replicate state of the route_estimate_via_mar_drc_patch property.
# route_estimate_via_mar_drc_patch has default value.
## Tcl commands to replicate state of the route_global_route_clock_nets_only property.
# route_global_route_clock_nets_only has default value.
## Tcl commands to replicate state of the route_guide_file property.
# route_guide_file has default value.
## Tcl commands to replicate state of the route_ordering_methods property.
# route_ordering_methods has default value.
## Tcl commands to replicate state of the route_ordering_priority property.
# route_ordering_priority has default value for all objects.
## Tcl commands to replicate state of the route_override_settings property.
# route_override_settings has default value.
## Tcl commands to replicate state of the route_preserve_temp_route_guides property.
# route_preserve_temp_route_guides has default value.
## Tcl commands to replicate state of the route_route_guide_record property.
set_ccopt_property route_route_guide_record {eagl_output /home/raid7_2/userb12/b12166/tmp/innovus_temp_27910_cad16_b12166_Y9q216/.rgfNnN3fg globalDetailRoute /home/raid7_2/userb12/b12166/tmp/innovus_temp_27910_cad16_b12166_Y9q216/.rgfNnN3fg}
## Tcl commands to replicate state of the route_topology property.
# route_topology has default value for all objects.
## Tcl commands to replicate state of the route_two_pass property.
# route_two_pass has default value.
## Tcl commands to replicate state of the route_two_pass_leaf_gcell_size property.
# route_two_pass_leaf_gcell_size has default value.
## Tcl commands to replicate state of the route_two_pass_trunk_gcell_size property.
# route_two_pass_trunk_gcell_size has default value.
## Tcl commands to replicate state of the route_type property.
set_ccopt_property route_type -clock_tree clk_p_i -net_type leaf default_route_type_leaf
set_ccopt_property route_type -clock_tree clk_p_i -net_type trunk default_route_type_nonleaf
set_ccopt_property route_type -clock_tree clk_p_i -net_type top default_route_type_nonleaf
## Tcl commands to replicate state of the route_type_autotrim property.
# route_type_autotrim has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_api property.
# route_type_autotrim_rc_api has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_match property.
# route_type_autotrim_rc_match has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_match_threshold property.
# route_type_autotrim_rc_match_threshold has default value.
## Tcl commands to replicate state of the route_type_autotrim_res_match_threshold property.
# route_type_autotrim_res_match_threshold has default value.
## Tcl commands to replicate state of the route_type_override_for_clustering property.
# route_type_override_for_clustering has default value for all objects.
## Tcl commands to replicate state of the route_type_override_preferred_routing_layer_effort property.
# route_type_override_preferred_routing_layer_effort has default value.
## Tcl commands to replicate state of the route_via_cell_choice_use_stack_via_rule property.
# route_via_cell_choice_use_stack_via_rule has default value.
## Tcl commands to replicate state of the routing_correlation_report_data_file property.
# routing_correlation_report_data_file has default value.
## Tcl commands to replicate state of the routing_correlation_report_low_fanout_cutoff property.
# routing_correlation_report_low_fanout_cutoff has default value.
## Tcl commands to replicate state of the routing_correlation_report_max_net_violation_count property.
# routing_correlation_report_max_net_violation_count has default value.
## Tcl commands to replicate state of the routing_cost_for_preferred_layer_effort_low property.
# routing_cost_for_preferred_layer_effort_low has default value.
## Tcl commands to replicate state of the routing_cost_for_preferred_layer_effort_medium property.
# routing_cost_for_preferred_layer_effort_medium has default value.
## Tcl commands to replicate state of the routing_estimate_add_extra_metal_for_through_vias property.
# routing_estimate_add_extra_metal_for_through_vias has default value.
## Tcl commands to replicate state of the routing_estimate_add_extra_metal_for_through_vias_length property.
# routing_estimate_add_extra_metal_for_through_vias_length has default value.
## Tcl commands to replicate state of the routing_estimate_detour_at_terminal_connection property.
# routing_estimate_detour_at_terminal_connection has default value.
## Tcl commands to replicate state of the routing_estimate_detour_override_to_layer property.
# routing_estimate_detour_override_to_layer has default value.
## Tcl commands to replicate state of the routing_estimate_eg_skip_unroutable_segments property.
# routing_estimate_eg_skip_unroutable_segments has default value.
## Tcl commands to replicate state of the routing_estimate_eg_use_guide_for_maze_fast property.
# routing_estimate_eg_use_guide_for_maze_fast has default value.
## Tcl commands to replicate state of the routing_estimate_egs_avoid_opt_path_on_maze property.
# routing_estimate_egs_avoid_opt_path_on_maze has default value.
## Tcl commands to replicate state of the routing_estimate_egs_opt_path_error_rate property.
# routing_estimate_egs_opt_path_error_rate has default value.
## Tcl commands to replicate state of the routing_estimate_hs_honor_global_topology property.
# routing_estimate_hs_honor_global_topology has default value.
## Tcl commands to replicate state of the routing_estimate_hs_layer_relax_cost property.
# routing_estimate_hs_layer_relax_cost has default value.
## Tcl commands to replicate state of the routing_estimate_hs_skip_unroutable_nets property.
# routing_estimate_hs_skip_unroutable_nets has default value.
## Tcl commands to replicate state of the routing_estimate_hs_use_top_two_layers property.
# routing_estimate_hs_use_top_two_layers has default value.
## Tcl commands to replicate state of the routing_estimate_num_rows_per_gcell property.
# routing_estimate_num_rows_per_gcell has default value.
## Tcl commands to replicate state of the routing_estimate_set_estimated_route_bit property.
# routing_estimate_set_estimated_route_bit has default value.
## Tcl commands to replicate state of the routing_estimate_set_hs_topology property.
# routing_estimate_set_hs_topology has default value.
## Tcl commands to replicate state of the routing_estimate_set_vias_with_tr property.
# routing_estimate_set_vias_with_tr has default value.
## Tcl commands to replicate state of the routing_estimate_short_terminal_connection_layer_override_passes property.
# routing_estimate_short_terminal_connection_layer_override_passes has default value.
## Tcl commands to replicate state of the routing_estimate_short_terminal_connection_layer_override_threshold property.
# routing_estimate_short_terminal_connection_layer_override_threshold has default value.
## Tcl commands to replicate state of the routing_estimate_use_early_global_route_properties property.
# routing_estimate_use_early_global_route_properties has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_connection_points property.
# routing_estimate_use_hs_connection_points has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_escape_pins property.
# routing_estimate_use_hs_escape_pins has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_layer_assignment property.
# routing_estimate_use_hs_layer_assignment has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_ndr_rule property.
# routing_estimate_use_hs_ndr_rule has default value.
## Tcl commands to replicate state of the routing_estimate_use_new_steiner_package property.
# routing_estimate_use_new_steiner_package has default value.
## Tcl commands to replicate state of the routing_override property.
# routing_override has default value for all objects.
## Tcl commands to replicate state of the routing_preferred_layer_effort_force_high property.
# routing_preferred_layer_effort_force_high has default value.
## Tcl commands to replicate state of the routing_save_datapath_trialroutes property.
# routing_save_datapath_trialroutes has default value.
## Tcl commands to replicate state of the routing_scale_factors property.
# routing_scale_factors has default value.
## Tcl commands to replicate state of the routing_top_fanout_count property.
# routing_top_fanout_count has default value for all objects.
## Tcl commands to replicate state of the routing_top_min_fanout property.
# routing_top_min_fanout has default value for all objects.
## Tcl commands to replicate state of the routing_use_highest_pin_layer property.
# routing_use_highest_pin_layer has default value.
## Tcl commands to replicate state of the row_height_multiplier_when_cleaning_up_net property.
# row_height_multiplier_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the run_latch_sta_during_slack_update property.
# run_latch_sta_during_slack_update has default value.
## Tcl commands to replicate state of the save_db_between_eagl_and_nr property.
# save_db_between_eagl_and_nr has default value.
## Tcl commands to replicate state of the save_design_in_qthread property.
# save_design_in_qthread has default value.
## Tcl commands to replicate state of the save_state_before_out_of_sync property.
# save_state_before_out_of_sync has default value.
## Tcl commands to replicate state of the scan_reorder property.
# scan_reorder has default value.
## Tcl commands to replicate state of the schedule property.
# schedule has default value for all objects.
## Tcl commands to replicate state of the search_sibling_footprints_for_equivalence property.
# search_sibling_footprints_for_equivalence has default value.
## Tcl commands to replicate state of the set_net_avoid_chaining property.
# set_net_avoid_chaining has default value.
## Tcl commands to replicate state of the set_propagated_clock property.
# set_propagated_clock has default value.
## Tcl commands to replicate state of the set_sink_centroid_as_cluster_center property.
# set_sink_centroid_as_cluster_center has default value.
## Tcl commands to replicate state of the show_property_errors_in_get_db property.
# show_property_errors_in_get_db has default value.
## Tcl commands to replicate state of the size_clock_source property.
# size_clock_source has default value for all objects.
## Tcl commands to replicate state of the size_logic property.
# size_logic has default value.
## Tcl commands to replicate state of the skew_band_minimum_adjustors property.
# skew_band_minimum_adjustors has default value.
## Tcl commands to replicate state of the skew_band_size property.
# skew_band_size has default value.
## Tcl commands to replicate state of the skew_group_property_keys_include_mode property.
set_ccopt_property skew_group_property_keys_include_mode 1
## Tcl commands to replicate state of the skew_group_report_columns property.
# skew_group_report_columns has default value.
## Tcl commands to replicate state of the skew_group_report_histogram_bin_size property.
# skew_group_report_histogram_bin_size has default value.
## Tcl commands to replicate state of the skew_pass_sufficient_progress_band_size_factor property.
# skew_pass_sufficient_progress_band_size_factor has default value.
## Tcl commands to replicate state of the skew_pass_sufficient_progress_band_size_factor_ideal_mode property.
# skew_pass_sufficient_progress_band_size_factor_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes property.
# skew_passes has default value.
## Tcl commands to replicate state of the skew_passes_ideal_mode property.
# skew_passes_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes_per_band property.
set_ccopt_property skew_passes_per_band 10
## Tcl commands to replicate state of the skew_passes_per_band_ideal_mode property.
# skew_passes_per_band_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes_per_band_with_latches property.
# skew_passes_per_band_with_latches has default value.
## Tcl commands to replicate state of the skew_passes_per_cluster property.
# skew_passes_per_cluster has default value.
## Tcl commands to replicate state of the skip_move_gates_in_chains property.
# skip_move_gates_in_chains has default value.
## Tcl commands to replicate state of the slew_fixing_start_upsizing_from_current_size property.
# slew_fixing_start_upsizing_from_current_size has default value.
## Tcl commands to replicate state of the small_trans_violation_threshold property.
# small_trans_violation_threshold has default value.
## Tcl commands to replicate state of the source_driver property.
# source_driver has default value for all objects.
## Tcl commands to replicate state of the source_group_clock_trees property.
# source_group_clock_trees has default value for all objects.
## Tcl commands to replicate state of the source_input_max_trans property.
# source_input_max_trans has default value for all objects.
## Tcl commands to replicate state of the source_latency property.
# source_latency has default value for all objects.
## Tcl commands to replicate state of the source_max_capacitance property.
# source_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the source_output_max_trans property.
# source_output_max_trans has default value for all objects.
## Tcl commands to replicate state of the stack_via_rule property.
# stack_via_rule has default value for all objects.
## Tcl commands to replicate state of the stacktrace_on_impccopt4375 property.
# stacktrace_on_impccopt4375 has default value.
## Tcl commands to replicate state of the stop_before_implementation property.
# stop_before_implementation has default value.
## Tcl commands to replicate state of the stop_before_long_segment_when_cleaning_up_net property.
# stop_before_long_segment_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the stop_before_preferred_layer_when_cleaning_up_net property.
# stop_before_preferred_layer_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the stop_if_clock_trees_modified property.
# stop_if_clock_trees_modified has default value.
## Tcl commands to replicate state of the stop_if_useful_skew_goes_backwards property.
# stop_if_useful_skew_goes_backwards has default value.
## Tcl commands to replicate state of the suppress_timing_updates_after_initial_cluster property.
# suppress_timing_updates_after_initial_cluster has default value.
## Tcl commands to replicate state of the suppress_timing_updates_after_initial_cluster_ideal_mode property.
# suppress_timing_updates_after_initial_cluster_ideal_mode has default value.
## Tcl commands to replicate state of the swapping_buffers_and_inverters_for_power_skip_latency_check property.
# swapping_buffers_and_inverters_for_power_skip_latency_check has default value.
## Tcl commands to replicate state of the target_em_max_capacitance property.
# target_em_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the target_insertion_delay property.
set_ccopt_property target_insertion_delay -skew_group default.clk_p_i/func_mode 0.5
set_ccopt_property target_insertion_delay -skew_group default.clk_p_i/scan_mode 0.5
set_ccopt_property target_insertion_delay -skew_group icts.clk_p_i/func_mode 0.5
set_ccopt_property target_insertion_delay -skew_group fragment.1 1.08745
## Tcl commands to replicate state of the target_insertion_delay_wire property.
# target_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the target_max_capacitance property.
# target_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the target_max_trans property.
# target_max_trans has default value for all objects.
## Tcl commands to replicate state of the target_max_trans_edge property.
# target_max_trans_edge has default value for all objects.
## Tcl commands to replicate state of the target_max_trans_sdc property.
# target_max_trans_sdc has default value for all objects.
## Tcl commands to replicate state of the target_multi_corner_allowed_insertion_delay_increase property.
# target_multi_corner_allowed_insertion_delay_increase has default value for all objects.
## Tcl commands to replicate state of the target_skew property.
set_ccopt_property target_skew -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -early default
set_ccopt_property target_skew -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -late default
set_ccopt_property target_skew -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -early default
set_ccopt_property target_skew -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -late default
set_ccopt_property target_skew -delay_corner DC_max -skew_group fragment.1 -late 0.0205
## Tcl commands to replicate state of the target_skew_wire property.
set_ccopt_property target_skew_wire -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -early default
set_ccopt_property target_skew_wire -delay_corner DC_max -skew_group icts.clk_p_i/func_mode -late default
set_ccopt_property target_skew_wire -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -early default
set_ccopt_property target_skew_wire -delay_corner DC_min -skew_group icts.clk_p_i/func_mode -late default
set_ccopt_property target_skew_wire -delay_corner DC_max -skew_group fragment.1 -late 0
## Tcl commands to replicate state of the threshold_for_design_being_routed property.
# threshold_for_design_being_routed has default value.
## Tcl commands to replicate state of the tighten_max_trans_band_size property.
# tighten_max_trans_band_size has default value.
## Tcl commands to replicate state of the time_clock_tree_disconnected property.
# time_clock_tree_disconnected has default value.
## Tcl commands to replicate state of the timing_connectivity_based_skew_groups property.
# timing_connectivity_based_skew_groups has default value.
## Tcl commands to replicate state of the timing_connectivity_based_skew_groups_balance_master_clocks property.
# timing_connectivity_based_skew_groups_balance_master_clocks has default value.
## Tcl commands to replicate state of the timing_delta property.
# timing_delta has default value.
## Tcl commands to replicate state of the top_buffer_cells property.
# top_buffer_cells has default value for all objects.
## Tcl commands to replicate state of the top_inverter_cells property.
# top_inverter_cells has default value for all objects.
## Tcl commands to replicate state of the trace_bidi_as_input property.
# trace_bidi_as_input has default value.
## Tcl commands to replicate state of the trade_right_size_for_delay_factor property.
# trade_right_size_for_delay_factor has default value.
## Tcl commands to replicate state of the trans_violation_report_num_buckets property.
# trans_violation_report_num_buckets has default value.
## Tcl commands to replicate state of the transition_report_in_dag_stats_num_bins property.
# transition_report_in_dag_stats_num_bins has default value.
## Tcl commands to replicate state of the treat_clock_gates_as_logics property.
# treat_clock_gates_as_logics has default value.
## Tcl commands to replicate state of the treat_null_power_domain_as_default property.
# treat_null_power_domain_as_default has default value.
## Tcl commands to replicate state of the treat_special_nets_as_routing_blockages property.
# treat_special_nets_as_routing_blockages has default value.
## Tcl commands to replicate state of the trial_balance_large_virtual_delay_bail_threshold property.
# trial_balance_large_virtual_delay_bail_threshold has default value.
## Tcl commands to replicate state of the trial_balance_large_virtual_delay_factor property.
# trial_balance_large_virtual_delay_factor has default value.
## Tcl commands to replicate state of the trial_balance_sink_driver_bail_threshold property.
# trial_balance_sink_driver_bail_threshold has default value.
## Tcl commands to replicate state of the trial_route_after_commit_net_attributes_and_route_estimates property.
# trial_route_after_commit_net_attributes_and_route_estimates has default value.
## Tcl commands to replicate state of the trial_route_in_synth_clock_trees property.
# trial_route_in_synth_clock_trees has default value.
## Tcl commands to replicate state of the trim_cell_lists_using_cell_properties property.
# trim_cell_lists_using_cell_properties has default value.
## Tcl commands to replicate state of the trunk_override property.
# trunk_override has default value for all objects.
## Tcl commands to replicate state of the try_harder_to_minimize_skew property.
# try_harder_to_minimize_skew has default value for all objects.
## Tcl commands to replicate state of the up_skew_band_size_ideal_mode property.
# up_skew_band_size_ideal_mode has default value.
## Tcl commands to replicate state of the update_io_latency property.
# update_io_latency has default value.
## Tcl commands to replicate state of the update_io_latency_after_implementation property.
# update_io_latency_after_implementation has default value.
## Tcl commands to replicate state of the update_lock_records_after_post_clustering_refine_place property.
# update_lock_records_after_post_clustering_refine_place has default value.
## Tcl commands to replicate state of the update_lock_records_after_refine_place property.
# update_lock_records_after_refine_place has default value.
## Tcl commands to replicate state of the update_movement_limit_after_clustering property.
# update_movement_limit_after_clustering has default value.
## Tcl commands to replicate state of the update_slacks_before_skewing_adjustors property.
# update_slacks_before_skewing_adjustors has default value.
## Tcl commands to replicate state of the update_timing_after_cts property.
# update_timing_after_cts has default value.
## Tcl commands to replicate state of the update_timing_after_resynth property.
# update_timing_after_resynth has default value.
## Tcl commands to replicate state of the uplift_limit property.
# uplift_limit has default value.
## Tcl commands to replicate state of the uplift_max_slack_loss property.
# uplift_max_slack_loss has default value.
## Tcl commands to replicate state of the uplift_min property.
# uplift_min has default value.
## Tcl commands to replicate state of the uplifts_band_size property.
# uplifts_band_size has default value.
## Tcl commands to replicate state of the use_accurate_downstream_capacitance_in_optimization property.
# use_accurate_downstream_capacitance_in_optimization has default value.
## Tcl commands to replicate state of the use_cte_dynamic_constraints property.
# use_cte_dynamic_constraints has default value.
## Tcl commands to replicate state of the use_cte_virtual_delays property.
# use_cte_virtual_delays has default value.
## Tcl commands to replicate state of the use_default_box_for_legalization property.
# use_default_box_for_legalization has default value.
## Tcl commands to replicate state of the use_delayed_legalization property.
# use_delayed_legalization has default value.
## Tcl commands to replicate state of the use_eagl_routes_for_congestion_update property.
# use_eagl_routes_for_congestion_update has default value.
## Tcl commands to replicate state of the use_early_global_for_clock_routing property.
# use_early_global_for_clock_routing has default value.
## Tcl commands to replicate state of the use_estimated_routes_during_final_implementation property.
# use_estimated_routes_during_final_implementation has default value.
## Tcl commands to replicate state of the use_fast_delay_arc_phase_transform property.
# use_fast_delay_arc_phase_transform has default value.
## Tcl commands to replicate state of the use_guides_with_freedom_regions property.
# use_guides_with_freedom_regions has default value.
## Tcl commands to replicate state of the use_inverters property.
# use_inverters has default value for all objects.
## Tcl commands to replicate state of the use_old_prim_dijkstra_interface property.
# use_old_prim_dijkstra_interface has default value.
## Tcl commands to replicate state of the use_only_combinational_arcs property.
# use_only_combinational_arcs has default value.
## Tcl commands to replicate state of the use_only_setup_views_for_target_insertion_delay property.
# use_only_setup_views_for_target_insertion_delay has default value.
## Tcl commands to replicate state of the use_optimal_skew_band property.
# use_optimal_skew_band has default value.
## Tcl commands to replicate state of the use_overlay_algorithms_when_single_threaded property.
# use_overlay_algorithms_when_single_threaded has default value.
## Tcl commands to replicate state of the use_sdc_annotation_for_ideal_nets property.
# use_sdc_annotation_for_ideal_nets has default value.
## Tcl commands to replicate state of the use_setup_and_hold_views_for_create_clock_tree_spec property.
# use_setup_and_hold_views_for_create_clock_tree_spec has default value.
## Tcl commands to replicate state of the use_setup_and_hold_views_for_implementation_windows property.
# use_setup_and_hold_views_for_implementation_windows has default value.
## Tcl commands to replicate state of the useful_skew_adjust_gates_final_pass_only property.
# useful_skew_adjust_gates_final_pass_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_macros_first_pass_only property.
# useful_skew_adjust_macros_first_pass_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_macros_first_pass_only_ideal_mode property.
# useful_skew_adjust_macros_first_pass_only_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_adjust_worst_n_pct_only property.
# useful_skew_adjust_worst_n_pct_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_worst_n_pct_only_ideal_mode property.
# useful_skew_adjust_worst_n_pct_only_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_adjustment_sequence property.
# useful_skew_adjustment_sequence has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows property.
# useful_skew_align_tns_windows has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows_min_size property.
# useful_skew_align_tns_windows_min_size has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows_quantum property.
# useful_skew_align_tns_windows_quantum has default value.
## Tcl commands to replicate state of the useful_skew_assert_output_pin_network_latencies property.
# useful_skew_assert_output_pin_network_latencies has default value.
## Tcl commands to replicate state of the useful_skew_build_below_clock_gate_skew_groups property.
# useful_skew_build_below_clock_gate_skew_groups has default value.
## Tcl commands to replicate state of the useful_skew_clear_network_latency_map property.
# useful_skew_clear_network_latency_map has default value.
## Tcl commands to replicate state of the useful_skew_clock_gate_movement_limit property.
# useful_skew_clock_gate_movement_limit has default value.
## Tcl commands to replicate state of the useful_skew_clock_gate_window_slack_budget property.
# useful_skew_clock_gate_window_slack_budget has default value.
## Tcl commands to replicate state of the useful_skew_clustering_cache_hold_slacks property.
# useful_skew_clustering_cache_hold_slacks has default value.
## Tcl commands to replicate state of the useful_skew_compute_slack_windows_by_category property.
# useful_skew_compute_slack_windows_by_category has default value.
## Tcl commands to replicate state of the useful_skew_configure_ideal_mode_reference property.
# useful_skew_configure_ideal_mode_reference has default value.
## Tcl commands to replicate state of the useful_skew_convert_default_mode_for_clock_domain_mode property.
# useful_skew_convert_default_mode_for_clock_domain_mode has default value.
## Tcl commands to replicate state of the useful_skew_cppr_timing_threshold property.
# useful_skew_cppr_timing_threshold has default value.
## Tcl commands to replicate state of the useful_skew_dont_skew_adjustor_if_unbufferable_children property.
# useful_skew_dont_skew_adjustor_if_unbufferable_children has default value.
## Tcl commands to replicate state of the useful_skew_enable_flop_merge_split_support property.
# useful_skew_enable_flop_merge_split_support has default value.
## Tcl commands to replicate state of the useful_skew_enable_macro_only_passes property.
# useful_skew_enable_macro_only_passes has default value.
## Tcl commands to replicate state of the useful_skew_equalize_offsets_use_chosen_windows property.
set_ccopt_property useful_skew_equalize_offsets_use_chosen_windows 1
## Tcl commands to replicate state of the useful_skew_equalize_offsets_use_chosen_windows_ideal_mode property.
# useful_skew_equalize_offsets_use_chosen_windows_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_export_implementation_windows_file property.
# useful_skew_export_implementation_windows_file has default value.
## Tcl commands to replicate state of the useful_skew_final_db property.
# useful_skew_final_db has default value.
## Tcl commands to replicate state of the useful_skew_hold_threshold_window_size property.
# useful_skew_hold_threshold_window_size has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_as_extra_effort_in_ideal_mode property.
# useful_skew_hyperspace_uplift_as_extra_effort_in_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_as_extra_effort_num_iterations property.
# useful_skew_hyperspace_uplift_as_extra_effort_num_iterations has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_max_fraction_per_subtree property.
# useful_skew_hyperspace_uplift_max_fraction_per_subtree has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_try_local_adjustment_first property.
# useful_skew_hyperspace_uplift_try_local_adjustment_first has default value.
## Tcl commands to replicate state of the useful_skew_ideal_delta_opt_on_only property.
# useful_skew_ideal_delta_opt_on_only has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_apply_move_limit property.
# useful_skew_ideal_mode_apply_move_limit has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_early_global_route_clock_nets property.
# useful_skew_ideal_mode_early_global_route_clock_nets has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_early_global_route_for_opus_drv property.
# useful_skew_ideal_mode_early_global_route_for_opus_drv has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_ideal_delta_opt_on_only property.
# useful_skew_ideal_mode_ideal_delta_opt_on_only has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_ignore_bufferability property.
# useful_skew_ideal_mode_ignore_bufferability has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_max_allowed_delay property.
set_ccopt_property useful_skew_ideal_mode_max_allowed_delay 1
## Tcl commands to replicate state of the useful_skew_ideal_mode_min_allowed_delay property.
# useful_skew_ideal_mode_min_allowed_delay has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_min_forwarding_skew property.
# useful_skew_ideal_mode_min_forwarding_skew has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_reference_by_clock property.
# useful_skew_ideal_mode_reference_by_clock has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_reference_quantum property.
# useful_skew_ideal_mode_reference_quantum has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_set_clock_latency property.
# useful_skew_ideal_mode_set_clock_latency has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_set_clock_latency_on_propagated_mode_clocks property.
# useful_skew_ideal_mode_set_clock_latency_on_propagated_mode_clocks has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_unfix_estimated_clock_routes property.
# useful_skew_ideal_mode_unfix_estimated_clock_routes has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_use_fast_trial_balancer property.
# useful_skew_ideal_mode_use_fast_trial_balancer has default value.
## Tcl commands to replicate state of the useful_skew_implement_with_clock_gate_skew_groups property.
# useful_skew_implement_with_clock_gate_skew_groups has default value.
## Tcl commands to replicate state of the useful_skew_implementation_cache_hold_slacks property.
# useful_skew_implementation_cache_hold_slacks has default value.
## Tcl commands to replicate state of the useful_skew_implementation_chosen_window_adjust property.
# useful_skew_implementation_chosen_window_adjust has default value.
## Tcl commands to replicate state of the useful_skew_import_implementation_windows_file property.
# useful_skew_import_implementation_windows_file has default value.
## Tcl commands to replicate state of the useful_skew_incremental_latch_sta property.
# useful_skew_incremental_latch_sta has default value.
## Tcl commands to replicate state of the useful_skew_macro_pin_count_threshold property.
# useful_skew_macro_pin_count_threshold has default value.
## Tcl commands to replicate state of the useful_skew_max_down_skew_fraction_per_round property.
# useful_skew_max_down_skew_fraction_per_round has default value.
## Tcl commands to replicate state of the useful_skew_max_down_skew_fraction_per_round_ideal_mode property.
# useful_skew_max_down_skew_fraction_per_round_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_max_sources_per_clock_gate_skew_group property.
# useful_skew_max_sources_per_clock_gate_skew_group has default value.
## Tcl commands to replicate state of the useful_skew_max_up_skew_fraction_per_round property.
# useful_skew_max_up_skew_fraction_per_round has default value.
## Tcl commands to replicate state of the useful_skew_max_up_skew_fraction_per_round_ideal_mode property.
# useful_skew_max_up_skew_fraction_per_round_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_max_window_down_delay_factor property.
# useful_skew_max_window_down_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_max_window_up_delay_factor property.
# useful_skew_max_window_up_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_min_delta property.
# useful_skew_min_delta has default value.
## Tcl commands to replicate state of the useful_skew_min_wns_window_factor property.
# useful_skew_min_wns_window_factor has default value.
## Tcl commands to replicate state of the useful_skew_minimum_slack_change property.
# useful_skew_minimum_slack_change has default value.
## Tcl commands to replicate state of the useful_skew_multi_corner property.
# useful_skew_multi_corner has default value.
## Tcl commands to replicate state of the useful_skew_node_to_node_pin_insertion_delays property.
# useful_skew_node_to_node_pin_insertion_delays has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_sinks property.
# useful_skew_only_adjust_critical_gigaopt_sinks has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_sinks_ideal_mode property.
# useful_skew_only_adjust_critical_gigaopt_sinks_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_overshoot property.
# useful_skew_overshoot has default value.
## Tcl commands to replicate state of the useful_skew_post_clustering_latch_sta property.
set_ccopt_property useful_skew_post_clustering_latch_sta 1
## Tcl commands to replicate state of the useful_skew_postconditioning_check_sibling_slacks property.
# useful_skew_postconditioning_check_sibling_slacks has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_buffer_insertion property.
# useful_skew_postconditioning_enable_buffer_insertion has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_buffer_removal property.
# useful_skew_postconditioning_enable_buffer_removal has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_move_gate property.
# useful_skew_postconditioning_enable_move_gate has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_resize_gate property.
# useful_skew_postconditioning_enable_resize_gate has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_sink_buffering property.
# useful_skew_postconditioning_enable_sink_buffering has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_slack_estimation property.
# useful_skew_postconditioning_enable_slack_estimation has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_initial_min_delay_unit_delay_factor property.
# useful_skew_postconditioning_initial_min_delay_unit_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_iterations property.
# useful_skew_postconditioning_iterations has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_min_delta_factor property.
# useful_skew_postconditioning_min_delta_factor has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_optimizations_per_iteration property.
# useful_skew_postconditioning_optimizations_per_iteration has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_slack_estimation_factor property.
# useful_skew_postconditioning_slack_estimation_factor has default value.
## Tcl commands to replicate state of the useful_skew_recluster_push_clock_gates_into_windows property.
# useful_skew_recluster_push_clock_gates_into_windows has default value.
## Tcl commands to replicate state of the useful_skew_refresh_adjustors_per_band_skew_pass property.
# useful_skew_refresh_adjustors_per_band_skew_pass has default value.
## Tcl commands to replicate state of the useful_skew_removable_clustering_delay_factor property.
# useful_skew_removable_clustering_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_report_detailed_slack_changes property.
# useful_skew_report_detailed_slack_changes has default value.
## Tcl commands to replicate state of the useful_skew_report_implementation_schedule_file property.
# useful_skew_report_implementation_schedule_file has default value.
## Tcl commands to replicate state of the useful_skew_report_implementation_skewing_offsets_file property.
# useful_skew_report_implementation_skewing_offsets_file has default value.
## Tcl commands to replicate state of the useful_skew_report_unbufferable_clock_nets_ideal_mode property.
# useful_skew_report_unbufferable_clock_nets_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_save_ccopt_mode_for_save_restore property.
set_ccopt_property useful_skew_save_ccopt_mode_for_save_restore default
## Tcl commands to replicate state of the useful_skew_show_all_high_effort_path_group_timing_stats property.
# useful_skew_show_all_high_effort_path_group_timing_stats has default value.
## Tcl commands to replicate state of the useful_skew_sink_safety_margin property.
# useful_skew_sink_safety_margin has default value.
## Tcl commands to replicate state of the useful_skew_slack_window_tns_offset_factor property.
# useful_skew_slack_window_tns_offset_factor has default value.
## Tcl commands to replicate state of the useful_skew_slack_window_wns_offset_factor property.
# useful_skew_slack_window_wns_offset_factor has default value.
## Tcl commands to replicate state of the useful_skew_use_clock_gate_network_latencies property.
# useful_skew_use_clock_gate_network_latencies has default value.
## Tcl commands to replicate state of the useful_skew_use_clock_network_slacks property.
# useful_skew_use_clock_network_slacks has default value.
## Tcl commands to replicate state of the useful_skew_use_gigaopt_for_mfn_chain_speed property.
# useful_skew_use_gigaopt_for_mfn_chain_speed has default value.
## Tcl commands to replicate state of the useful_skew_use_zero_delays_for_clock_domain_mode property.
# useful_skew_use_zero_delays_for_clock_domain_mode has default value.
## Tcl commands to replicate state of the useful_skew_window_size property.
# useful_skew_window_size has default value.
## Tcl commands to replicate state of the useful_skew_window_top_unit_delay_factor property.
# useful_skew_window_top_unit_delay_factor has default value.
## Tcl commands to replicate state of the user_skew_group property.
set_ccopt_property user_skew_group -skew_group default.clk_p_i/func_mode 1
set_ccopt_property user_skew_group -skew_group default.clk_p_i/scan_mode 1
## Tcl commands to replicate state of the virtual_delay property.
# virtual_delay has default value for all objects.
## Tcl commands to replicate state of the virtual_delay_report_in_dag_stats_num_bins property.
# virtual_delay_report_in_dag_stats_num_bins has default value.
## Tcl commands to replicate state of the weak_driver_check_bounding_box_vs_drive_distance property.
# weak_driver_check_bounding_box_vs_drive_distance has default value.
## Tcl commands to replicate state of the write_clock_dag_hash_for_every_step property.
# write_clock_dag_hash_for_every_step has default value.
## Tcl commands to replicate state of the write_clock_dag_timing_stats_for_balancing_intermediate_steps property.
# write_clock_dag_timing_stats_for_balancing_intermediate_steps has default value.
## Tcl commands to replicate state of the write_routing_correlation_report_to_log property.
# write_routing_correlation_report_to_log has default value.
## Tcl commands to replicate state of the write_sink_depths_to_file property.
# write_sink_depths_to_file has default value.
#### End of writing state for properties.
